#include "StdAfx.h"

#include "math.h"
#include ".\GPCommon.h"

#include "stdio.h"

#using <mscorlib.dll>


CGPCommon::CGPCommon(void)
{
}

CGPCommon::~CGPCommon(void)
{
}


std::vector<CGPCommonDefinition::strct_LandMarks > CGPCommon::_vec_LandMarks;

std::vector<std::vector <CGPCommonDefinition::strct_SeaLine >> CGPCommon::_vec_vec_SeaLine;

std::multimap<std::string, CGPCommonDefinition::strct_Trail> CGPCommon::_mltMapTrail;
 
std::map<std::string, CGPCommonDefinition::DispPos2D > CGPCommon::_mapDispPos;  // 

std::map<std::string, std::string > CGPCommon::_mapFlightCode;  // 

std::string CGPCommon::strHex_pointing_Now; 

std::queue<std::vector<strct_ADS > >  CGPCommon::_que_vec_ADS;

std::vector<strct_ADS >	CGPCommon::_vec_ADS;

int CGPCommon::TimerInterval=1000;

std::string CGPCommon::strLogFileWithFullPath;

//std::vector<std::string > CGPCommon::vec_Image_Files;


std::vector<CGPCommonDefinition::SystemParam > CGPCommon::_vecSystemParam;

std::string CGPCommon::strFormerForSystemParamDirtyCheck;
std::string CGPCommon::strLatterForSystemParamDirtyCheck;

std::string CGPCommon::_strDataFolder;

bool CGPCommon::IsBusyNow = false;  

bool CGPCommon::IsTrail = false;

int CGPCommon::IsDemoMode;
int CGPCommon::demo_Span_ms;
int CGPCommon::demoStartNo;
int CGPCommon::demoEndNo;
int CGPCommon::TailNo; 
int CGPCommon::nDispKind; 
int CGPCommon::IsPlaneMark;
int CGPCommon::Height_Line_Span;
int CGPCommon::trailThickness;
int CGPCommon::hojyoenNo; 
int CGPCommon::nuritsubushi; 
int CGPCommon::IsEquator; 
int CGPCommon::IsKEISEN;	
int CGPCommon::D_Height;
int CGPCommon::Height_exaggeration;
int CGPCommon::Elevation_angle_kind;
int CGPCommon::trailMovingAverage_N;

int CGPCommon::UpdateSystemParam(){

	////////////////////////////////////
	CGPCommonDefinition::SystemParam param;

	CGPCommon::get_SystemParam("S001", param);
	CGPCommon::IsDemoMode = param.VALUE;
	 
	CGPCommon::get_SystemParam("S002", param);
	CGPCommon::demo_Span_ms = param.VALUE;

	CGPCommon::get_SystemParam("S003", param);
	CGPCommon::demoStartNo = param.VALUE;

	CGPCommon::get_SystemParam("S004", param);
	CGPCommon::demoEndNo = param.VALUE;

	CGPCommon::get_SystemParam("S005", param);
	CGPCommon::TailNo = param.VALUE;

	CGPCommon::get_SystemParam("S006", param);
	CGPCommon::nDispKind = param.VALUE;
 
	CGPCommon::get_SystemParam("S007", param);
	CGPCommon::IsPlaneMark = param.VALUE;

	CGPCommon::get_SystemParam("S008", param);
	CGPCommon::Height_Line_Span = param.VALUE;

	CGPCommon::get_SystemParam("S009", param);
	CGPCommon::trailThickness = param.VALUE;

	CGPCommon::get_SystemParam("S010", param);
	CGPCommon::hojyoenNo = param.VALUE;

	CGPCommon::get_SystemParam("S011", param);
	CGPCommon::nuritsubushi  = param.VALUE;

	CGPCommon::get_SystemParam("S012", param);
	CGPCommon::IsEquator = param.VALUE;

	CGPCommon::get_SystemParam("S013", param);
	CGPCommon::IsKEISEN = param.VALUE;

	CGPCommon::get_SystemParam("S014", param);
	CGPCommon::D_Height = param.VALUE;

	CGPCommon::get_SystemParam("S015", param);
	CGPCommon::Height_exaggeration = param.VALUE;

	CGPCommon::get_SystemParam("S016", param);
	CGPCommon::Elevation_angle_kind = param.VALUE;

	CGPCommon::get_SystemParam("S017", param);
	CGPCommon::trailMovingAverage_N = param.VALUE;

	return(0);
}
int CGPCommon::get_SystemParam(char* CODE, CGPCommonDefinition::SystemParam& param){

	int ret = -1;  //�����l

	int size = _vecSystemParam.size();
	if (size<1) {
		return(ret);
	}

	for (int i = 0; i<size; i++){
		CGPCommonDefinition::SystemParam pd;
		pd = _vecSystemParam[i];
		if (!strcmp(CODE, pd.CODE.c_str())){
			//�r���S
			param = pd;
			ret = 0;
			break;
		}
	}

	return(ret);
}