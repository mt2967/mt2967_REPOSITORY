﻿// GlidePath
// 2025-10-26 修正
// 2025-11-04 立面図機能追加

#pragma once
#pragma warning(disable : 4996)  // sprintfの警告を無視。
#pragma warning(disable : 4244)  // 変換の警告を無視。


#include <vector> 
#include <map>
#include <set>

#include "stdafx.h"
#include "windows.h"

#include "math.h" 
#include <algorithm>
#include "iostream"

#include "./MngFnc.h" 
#include "GPCommon.h"

#include "Mat2.h"	//２次元行列
#include "Mat3.h"	//３次元行列


#define SYSTEM_PARAM_FILE "C:/ADS_GLIDE_PATH/Parameter/SystemParameter.csv"
#define STRING_PARAM_FILE "C:/ADS_GLIDE_PATH/Parameter/StringParameters.csv"

#define SOUND_FILE "C:/ADS_GLIDE_PATH/Parameter/Sound_Seatbelt.wav"
#define DEMO_FILE "C:/ADS_GLIDE_PATH/DemoData/tmp_ADS_B-0000"

#define LOCATION_FILE "C:/ADS_GLIDE_PATH/Parameter/LocationList.csv"
#define SEALINE_FILE "C:/ADS_GLIDE_PATH/Parameter/SeaLine.csv"


#define PI 3.141592653

#define PROGRESS_DRAW -2

#define D666 666
#define SPEED_FCT 0.066*1.25   //  300マイル毎時が20*1.25画素 
 
//#define MaxDegRITSUMEN 90  ///  90  //30
#define M180 180

double D2R = PI / 180.0;

//////////////////////////////
// 通常型のコモン変数はここ
//////////////////////////////
long int gCnt = 0;

bool bIsFirstError = true;
bool bIsFirstPrint = true;
bool bIsGenerateMap = true;

//int  gHeightOrAngle = 1;  //2025-11-04 

int gLx, gLy;

double gROUND_DEG; //回転角
double gDEPRS_DEG; //俯角
double gRadius_km;

double gROUND_DEG_former=-360;
double gDEPRS_DEG_former=0;
double gRadius_km_former=100;

long long gMaxSize_multimap;

int gNumQueue;

int gPlaneNum;

int gIsEnglish = 1;  //1=英語UIを優先

static CRITICAL_SECTION gCS;

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;

using namespace Windows::Forms;
using namespace CGPCommonDefinition;


namespace Glide_Path {

	/// <summary>
	/// Form1 の概要
	///
	/// 警告: このクラスの名前を変更する場合、このクラスが依存するすべての .resx ファイルに関連付けられた
	///          マネージ リソース コンパイラ ツールに対して 'Resource File Name' プロパティを
	///          変更する必要があります。この変更を行わないと、
	///          デザイナと、このフォームに関連付けられたローカライズ済みリソースとが、
	///          正しく相互に利用できなくなります。
	/// </summary>




	public ref class Form1 : public System::Windows::Forms::Form
	{

	public:

		////////////////////////////////////////////////
		// スコープ注意
		// グローバルに使用したいので、外側に置きます。
		// マネージ型なので、これ以上外には宣言できない。
		// 
		////////////////////////////////////////////////

		//Int^ gIsENGLISH = 1;

		Diagnostics::Stopwatch^ gSw;
		String^ gSystemParamFile;
		Bitmap^ g_bmpPicBox1;  //2023-04-03
		Bitmap^ g_bmpPicBox2;  //2023-04-03

		String^ gFormerName_for_API_BUG_taisaku = "ABC";

		Pen^ penRed;
		Pen^ penEquator;
		Pen^ pen_PV_Red;
		Pen^ penWhite;
		Pen^ penGlay;
		Pen^ penYellow;
		Pen^ penLightBlue;
		Pen^ penDownTrail;
		Pen^ penUpTrail;

		Pen^ penDownTrail1;
		Pen^ penDownTrail2;
		Pen^ penDownTrail3;
		Pen^ penDownTrail4;
		Pen^ penDownTrail5;
		Pen^ penDownTrail6;
		Pen^ penDownTrail7;
		Pen^ penDownTrail8;
		Pen^ penDownTrail9;
		Pen^ penDownTrail10; 

		Pen^ penUpTrail1;
		Pen^ penUpTrail2;
		Pen^ penUpTrail3;
		Pen^ penUpTrail4;
		Pen^ penUpTrail5;
		Pen^ penUpTrail6;
		Pen^ penUpTrail7;
		Pen^ penUpTrail8;
		Pen^ penUpTrail9;
		Pen^ penUpTrail10;


		Pen^ penDimGray_Dot;
		Pen^ penDimGray_Dash;
		Pen^ penSeaLine;
		Pen^ penLongitude;
		Pen^ penLatitude;

		System::Drawing::Font^ fntL;
		System::Drawing::Font^ fntM;
		System::Drawing::Font^ fntS;
		System::Drawing::Font^ fntXS;

		SolidBrush^ brYellow;
		SolidBrush^ brMagenta;
		SolidBrush^ brWhite;
		SolidBrush^ brRed;
		SolidBrush^ brLand1;
		SolidBrush^ brLand2;
		SolidBrush^ brLand3;
		SolidBrush^ brLand4;
		SolidBrush^ brLand5;

		Graphics^ _Grph1;  //2023-12-07 
		Graphics^ _Grph2;  //2023-12-07 

	private: System::Windows::Forms::ListBox^ listBoxKijyunLoc;
	public:
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown1;
	private: System::Windows::Forms::TabControl^ tabControl1;
	private: System::Windows::Forms::TabPage^ tabPage0;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Label^ label_KANSHI_info;
	private: System::Windows::Forms::TabPage^ tabPage2;
	private: System::Windows::Forms::Label^ label_SystemParamFileName;
	private: System::Windows::Forms::Button^ buttonRenew;
	private: System::Windows::Forms::DataGridView^ dataGridViewSystemParamTable;



	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Button^ buttonEnd;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown2;
	private: System::Windows::Forms::CheckBox^ checkBoxTrail;
	private: System::Windows::Forms::Label^ label19;
	private: System::Windows::Forms::NumericUpDown^ numericUpDown3;
	private: System::Windows::Forms::Button^ buttonDemoStart;
	private: System::ComponentModel::BackgroundWorker^ backgroundWorker1;
	private: System::Windows::Forms::ProgressBar^ progressBar1;
	private: System::ComponentModel::BackgroundWorker^ backgroundWorker2;

	public:























	public:
		SolidBrush^ brBlue;
	private: System::Windows::Forms::FlowLayoutPanel^ flowLayoutPanel1;



private: System::Windows::Forms::PictureBox^ pictureBox2;
private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column2;
private: System::Windows::Forms::DataGridViewTextBoxColumn^ Column3;



	public:
		SolidBrush^ brGray;

	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: ここにコンストラクタ コードを追加します
			//

			//ホイールイベントの登録
			this->MouseWheel += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::Form1_MouseWheel);
		}

	protected:
		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:




	private:





	private: System::IO::FileSystemWatcher^ fileSystemWatcher1;

























	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// 必要なデザイナ変数です。
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle1 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle2 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^ dataGridViewCellStyle3 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->fileSystemWatcher1 = (gcnew System::IO::FileSystemWatcher());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage0 = (gcnew System::Windows::Forms::TabPage());
			this->flowLayoutPanel1 = (gcnew System::Windows::Forms::FlowLayoutPanel());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->checkBoxTrail = (gcnew System::Windows::Forms::CheckBox());
			this->listBoxKijyunLoc = (gcnew System::Windows::Forms::ListBox());
			this->buttonEnd = (gcnew System::Windows::Forms::Button());
			this->buttonDemoStart = (gcnew System::Windows::Forms::Button());
			this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
			this->label_KANSHI_info = (gcnew System::Windows::Forms::Label());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->label_SystemParamFileName = (gcnew System::Windows::Forms::Label());
			this->buttonRenew = (gcnew System::Windows::Forms::Button());
			this->dataGridViewSystemParamTable = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			this->backgroundWorker2 = (gcnew System::ComponentModel::BackgroundWorker());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->fileSystemWatcher1))->BeginInit();
			this->tabControl1->SuspendLayout();
			this->tabPage0->SuspendLayout();
			this->flowLayoutPanel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->tabPage2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridViewSystemParamTable))->BeginInit();
			this->SuspendLayout();
			// 
			// fileSystemWatcher1
			// 
			this->fileSystemWatcher1->EnableRaisingEvents = true;
			this->fileSystemWatcher1->SynchronizingObject = this;
			this->fileSystemWatcher1->Changed += gcnew System::IO::FileSystemEventHandler(this, &Form1::fileSystemWatcher1_Changed);
			this->fileSystemWatcher1->Created += gcnew System::IO::FileSystemEventHandler(this, &Form1::fileSystemWatcher1_Created);
			this->fileSystemWatcher1->Renamed += gcnew System::IO::RenamedEventHandler(this, &Form1::fileSystemWatcher1_Renamed);
			// 
			// tabControl1
			// 
			resources->ApplyResources(this->tabControl1, L"tabControl1");
			this->tabControl1->Controls->Add(this->tabPage0);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Multiline = true;
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Deselected += gcnew System::Windows::Forms::TabControlEventHandler(this, &Form1::tabControl1_Deselected);
			// 
			// tabPage0
			// 
			resources->ApplyResources(this->tabPage0, L"tabPage0");
			this->tabPage0->BackColor = System::Drawing::Color::AntiqueWhite;
			this->tabPage0->Controls->Add(this->flowLayoutPanel1);
			this->tabPage0->Controls->Add(this->pictureBox1);
			this->tabPage0->Controls->Add(this->button1);
			this->tabPage0->Name = L"tabPage0";
			this->tabPage0->Click += gcnew System::EventHandler(this, &Form1::tabPage0_Click);
			// 
			// flowLayoutPanel1
			// 
			resources->ApplyResources(this->flowLayoutPanel1, L"flowLayoutPanel1");
			this->flowLayoutPanel1->BackColor = System::Drawing::Color::CadetBlue;
			this->flowLayoutPanel1->Controls->Add(this->label3);
			this->flowLayoutPanel1->Controls->Add(this->numericUpDown1);
			this->flowLayoutPanel1->Controls->Add(this->label17);
			this->flowLayoutPanel1->Controls->Add(this->numericUpDown2);
			this->flowLayoutPanel1->Controls->Add(this->label19);
			this->flowLayoutPanel1->Controls->Add(this->numericUpDown3);
			this->flowLayoutPanel1->Controls->Add(this->checkBoxTrail);
			this->flowLayoutPanel1->Controls->Add(this->listBoxKijyunLoc);
			this->flowLayoutPanel1->Controls->Add(this->buttonEnd);
			this->flowLayoutPanel1->Controls->Add(this->buttonDemoStart);
			this->flowLayoutPanel1->Controls->Add(this->progressBar1);
			this->flowLayoutPanel1->Controls->Add(this->label_KANSHI_info);
			this->flowLayoutPanel1->Controls->Add(this->pictureBox2);
			this->flowLayoutPanel1->Name = L"flowLayoutPanel1";
			// 
			// label3
			// 
			resources->ApplyResources(this->label3, L"label3");
			this->label3->ForeColor = System::Drawing::Color::Black;
			this->label3->Name = L"label3";
			// 
			// numericUpDown1
			// 
			resources->ApplyResources(this->numericUpDown1, L"numericUpDown1");
			this->numericUpDown1->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 5, 0, 0, 0 });
			this->numericUpDown1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 450, 0, 0, 0 });
			this->numericUpDown1->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 450, 0, 0, System::Int32::MinValue });
			this->numericUpDown1->Name = L"numericUpDown1";
			this->numericUpDown1->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown1_ValueChanged);
			// 
			// label17
			// 
			resources->ApplyResources(this->label17, L"label17");
			this->label17->ForeColor = System::Drawing::Color::Black;
			this->label17->Name = L"label17";
			// 
			// numericUpDown2
			// 
			resources->ApplyResources(this->numericUpDown2, L"numericUpDown2");
			this->numericUpDown2->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 5, 0, 0, 0 });
			this->numericUpDown2->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 90, 0, 0, 0 });
			this->numericUpDown2->Name = L"numericUpDown2";
			this->numericUpDown2->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown2_ValueChanged);
			// 
			// label19
			// 
			resources->ApplyResources(this->label19, L"label19");
			this->label19->ForeColor = System::Drawing::Color::Black;
			this->label19->Name = L"label19";
			// 
			// numericUpDown3
			// 
			resources->ApplyResources(this->numericUpDown3, L"numericUpDown3");
			this->numericUpDown3->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 10, 0, 0, 0 });
			this->numericUpDown3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 40000, 0, 0, 0 });
			this->numericUpDown3->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 10, 0, 0, 0 });
			this->numericUpDown3->Name = L"numericUpDown3";
			this->numericUpDown3->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 130, 0, 0, 0 });
			this->numericUpDown3->ValueChanged += gcnew System::EventHandler(this, &Form1::numericUpDown3_ValueChanged);
			// 
			// checkBoxTrail
			// 
			resources->ApplyResources(this->checkBoxTrail, L"checkBoxTrail");
			this->checkBoxTrail->Name = L"checkBoxTrail";
			this->checkBoxTrail->UseVisualStyleBackColor = true;
			this->checkBoxTrail->CheckedChanged += gcnew System::EventHandler(this, &Form1::checkBoxTrail_CheckedChanged);
			// 
			// listBoxKijyunLoc
			// 
			resources->ApplyResources(this->listBoxKijyunLoc, L"listBoxKijyunLoc");
			this->listBoxKijyunLoc->BackColor = System::Drawing::Color::PaleGreen;
			this->listBoxKijyunLoc->MultiColumn = true;
			this->listBoxKijyunLoc->Name = L"listBoxKijyunLoc";
			this->listBoxKijyunLoc->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::listBoxKijyunLoc_SelectedIndexChanged);
			// 
			// buttonEnd
			// 
			resources->ApplyResources(this->buttonEnd, L"buttonEnd");
			this->buttonEnd->BackColor = System::Drawing::Color::Khaki;
			this->buttonEnd->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->buttonEnd->FlatAppearance->CheckedBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->buttonEnd->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Blue;
			this->buttonEnd->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->buttonEnd->Name = L"buttonEnd";
			this->buttonEnd->UseVisualStyleBackColor = false;
			this->buttonEnd->Click += gcnew System::EventHandler(this, &Form1::buttonEnd_Click);
			// 
			// buttonDemoStart
			// 
			resources->ApplyResources(this->buttonDemoStart, L"buttonDemoStart");
			this->buttonDemoStart->BackColor = System::Drawing::Color::Khaki;
			this->buttonDemoStart->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->buttonDemoStart->FlatAppearance->CheckedBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->buttonDemoStart->FlatAppearance->MouseDownBackColor = System::Drawing::Color::Blue;
			this->buttonDemoStart->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->buttonDemoStart->Name = L"buttonDemoStart";
			this->buttonDemoStart->UseVisualStyleBackColor = false;
			this->buttonDemoStart->Click += gcnew System::EventHandler(this, &Form1::buttonDemoStart_Click);
			// 
			// progressBar1
			// 
			resources->ApplyResources(this->progressBar1, L"progressBar1");
			this->progressBar1->Name = L"progressBar1";
			this->progressBar1->Click += gcnew System::EventHandler(this, &Form1::progressBar1_Click);
			// 
			// label_KANSHI_info
			// 
			resources->ApplyResources(this->label_KANSHI_info, L"label_KANSHI_info");
			this->label_KANSHI_info->BackColor = System::Drawing::Color::Gainsboro;
			this->label_KANSHI_info->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label_KANSHI_info->Name = L"label_KANSHI_info";
			// 
			// pictureBox2
			// 
			resources->ApplyResources(this->pictureBox2, L"pictureBox2");
			this->pictureBox2->BackColor = System::Drawing::Color::Black;
			this->pictureBox2->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox1
			// 
			resources->ApplyResources(this->pictureBox1, L"pictureBox1");
			this->pictureBox1->BackColor = System::Drawing::Color::Black;
			this->pictureBox1->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->TabStop = false;
			this->pictureBox1->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox1_MouseDown);
			this->pictureBox1->Resize += gcnew System::EventHandler(this, &Form1::pictureBox1_Resize);
			// 
			// button1
			// 
			resources->ApplyResources(this->button1, L"button1");
			this->button1->Name = L"button1";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// tabPage2
			// 
			resources->ApplyResources(this->tabPage2, L"tabPage2");
			this->tabPage2->BackColor = System::Drawing::Color::AntiqueWhite;
			this->tabPage2->Controls->Add(this->label_SystemParamFileName);
			this->tabPage2->Controls->Add(this->buttonRenew);
			this->tabPage2->Controls->Add(this->dataGridViewSystemParamTable);
			this->tabPage2->Name = L"tabPage2";
			// 
			// label_SystemParamFileName
			// 
			resources->ApplyResources(this->label_SystemParamFileName, L"label_SystemParamFileName");
			this->label_SystemParamFileName->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->label_SystemParamFileName->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->label_SystemParamFileName->ForeColor = System::Drawing::Color::Blue;
			this->label_SystemParamFileName->Name = L"label_SystemParamFileName";
			// 
			// buttonRenew
			// 
			resources->ApplyResources(this->buttonRenew, L"buttonRenew");
			this->buttonRenew->BackColor = System::Drawing::Color::Khaki;
			this->buttonRenew->Cursor = System::Windows::Forms::Cursors::Hand;
			this->buttonRenew->Name = L"buttonRenew";
			this->buttonRenew->UseVisualStyleBackColor = false;
			this->buttonRenew->Click += gcnew System::EventHandler(this, &Form1::buttonRenew_Click);
			// 
			// dataGridViewSystemParamTable
			// 
			resources->ApplyResources(this->dataGridViewSystemParamTable, L"dataGridViewSystemParamTable");
			this->dataGridViewSystemParamTable->AllowUserToAddRows = false;
			this->dataGridViewSystemParamTable->AllowUserToDeleteRows = false;
			this->dataGridViewSystemParamTable->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::DisableResizing;
			this->dataGridViewSystemParamTable->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {
				this->Column1,
					this->Column2, this->Column3
			});
			this->dataGridViewSystemParamTable->MultiSelect = false;
			this->dataGridViewSystemParamTable->Name = L"dataGridViewSystemParamTable";
			this->dataGridViewSystemParamTable->RowHeadersVisible = false;
			this->dataGridViewSystemParamTable->RowTemplate->Height = 30;
			this->dataGridViewSystemParamTable->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::FullRowSelect;
			// 
			// Column1
			// 
			dataGridViewCellStyle1->Font = (gcnew System::Drawing::Font(L"MS UI Gothic", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(128)));
			this->Column1->DefaultCellStyle = dataGridViewCellStyle1;
			this->Column1->Frozen = true;
			resources->ApplyResources(this->Column1, L"Column1");
			this->Column1->Name = L"Column1";
			this->Column1->ReadOnly = true;
			this->Column1->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// Column2
			// 
			dataGridViewCellStyle2->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleRight;
			this->Column2->DefaultCellStyle = dataGridViewCellStyle2;
			this->Column2->Frozen = true;
			resources->ApplyResources(this->Column2, L"Column2");
			this->Column2->Name = L"Column2";
			this->Column2->ReadOnly = true;
			this->Column2->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// Column3
			// 
			dataGridViewCellStyle3->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleRight;
			dataGridViewCellStyle3->Font = (gcnew System::Drawing::Font(L"MS UI Gothic", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(128)));
			this->Column3->DefaultCellStyle = dataGridViewCellStyle3;
			this->Column3->Frozen = true;
			resources->ApplyResources(this->Column3, L"Column3");
			this->Column3->Name = L"Column3";
			this->Column3->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// backgroundWorker1
			// 
			this->backgroundWorker1->WorkerReportsProgress = true;
			this->backgroundWorker1->WorkerSupportsCancellation = true;
			this->backgroundWorker1->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker1_DoWork);
			this->backgroundWorker1->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker1_ProgressChanged);
			this->backgroundWorker1->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker1_RunWorkerCompleted);
			// 
			// backgroundWorker2
			// 
			this->backgroundWorker2->WorkerReportsProgress = true;
			this->backgroundWorker2->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker2_DoWork);
			this->backgroundWorker2->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker2_ProgressChanged);
			this->backgroundWorker2->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker2_RunWorkerCompleted);
			// 
			// Form1
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LemonChiffon;
			this->Controls->Add(this->tabControl1);
			this->Name = L"Form1";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &Form1::Form1_FormClosed);
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->Shown += gcnew System::EventHandler(this, &Form1::Form1_Shown);
			this->Resize += gcnew System::EventHandler(this, &Form1::Form1_Resize);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->fileSystemWatcher1))->EndInit();
			this->tabControl1->ResumeLayout(false);
			this->tabPage0->ResumeLayout(false);
			this->flowLayoutPanel1->ResumeLayout(false);
			this->flowLayoutPanel1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->numericUpDown3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridViewSystemParamTable))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void buttonEnd_Click(System::Object^ sender, System::EventArgs^ e) {
 
		this->Close();
	}
 

	private: System::Void WindowToCenter() {

		//逆引きハンドブック　P195

		System::Drawing::Rectangle^ rect = Screen::PrimaryScreen->Bounds;
		int sx = rect->Width;
		int sy = rect->Height;


		this->Left = (sx - this->Width) / 2;
		this->Top = (sy - this->Height) / 2;

	}

	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {


		//２重起動の禁止
		String^ pname = System::Diagnostics::Process::GetCurrentProcess()->ProcessName;
		array <System::Diagnostics::Process^ >^ prvc = System::Diagnostics::Process::GetProcessesByName(pname);

		if (prvc->Length > 1) { //同じプロセスが２個以上あれば
			//すでに起動しているとみなす。
			MessageBox::Show("すでに起動しています", "確認");
			this->Close();
		}

		gSystemParamFile = gcnew String(SYSTEM_PARAM_FILE);
		this->label_SystemParamFileName->Text = gSystemParamFile;


		// システムパラメータを読んで、コモン変数に展開します。
		sub_ReadSystemParam();


		MngFnc::WriteCsvLog("Glide_Path起動しました");



		/////////////////////////////////
		// LocationList.csvを読み込む
		/////////////////////////////////
		{

			std::vector<std::vector<std::string > > vec_vec_strTable;
			vec_vec_strTable.clear();
			MngFnc::LoadCsvFileSkipHeader1(LOCATION_FILE, vec_vec_strTable);

			int num = vec_vec_strTable.size();

			for (int i = 0; i < num; i++) {

				std::vector<std::string > vecString = vec_vec_strTable[i];
				int num2 = vecString.size();

				if (num2 < 4) {
					break;
				}
				//strct_LandMarks sLM;
				CGPCommonDefinition::strct_LandMarks sLM;

				sLM.strShortName = vecString[0];
				sLM.ido = atof(vecString[1].c_str());
				sLM.keido = atof(vecString[2].c_str());
				sLM.strLongName = vecString[3];
				sLM.rank = atoi(vecString[4].c_str());

				CGPCommon::_vec_LandMarks.push_back(sLM);

				String^ S1 = gcnew String(sLM.strLongName.c_str());
				this->listBoxKijyunLoc->Items->Add(S1);

			}

		}

		/////////////////////////////
		// SelLine.csvを読み込む
		/////////////////////////////
		{

			std::vector<std::vector<std::string > > vec_vec_strTable;
			vec_vec_strTable.clear();
			MngFnc::LoadCsvFileSkipHeader1(SEALINE_FILE, vec_vec_strTable);

			int num = vec_vec_strTable.size();

			std::vector<CGPCommonDefinition::strct_SeaLine> vecSeaLine;

			for (int i = 0; i < num; i++) {

				std::vector<std::string > vecString = vec_vec_strTable[i];
				int num2 = vecString.size();

				if (num2 < 4) {
					break;
				} 

				CGPCommonDefinition::strct_SeaLine sSL;

				sSL.strStartEnd = vecString[0];
				sSL.ido = atof(vecString[1].c_str());
				sSL.keido = atof(vecString[2].c_str());
				sSL.strLongName = vecString[3];

				//CGPCommon::_vec_SeaLine.push_back(sSL);
				vecSeaLine.push_back(sSL);

				if (!sSL.strStartEnd.compare("E")) {
					CGPCommon::_vec_vec_SeaLine.push_back(vecSeaLine);
					vecSeaLine.clear();
				}

			}

		}

		//ストップウォッチの準備
		gSw = gcnew Diagnostics::Stopwatch();

		//
		gROUND_DEG = (double)this->numericUpDown1->Value;
		gDEPRS_DEG = (double)this->numericUpDown2->Value;
		gRadius_km = (double)this->numericUpDown3->Value;

		//フォームの最大化
		this->WindowState = FormWindowState::Maximized;

		//表示画面の高さ調整
		int dd = CGPCommon::D_Height;
		this->Height = this->Height + dd;
		this->pictureBox1->Height = this->pictureBox1->Height + dd;
		this->tabControl1->Height = this->tabControl1->Height + dd;


		//空のBMP領域を確保
		gLx = this->pictureBox1->Width;
		gLy = this->pictureBox1->Height;


		g_bmpPicBox1 = gcnew Bitmap(gLx, gLy);
		pictureBox1->Image = g_bmpPicBox1;  // in Form1_Load
		_Grph1 = Graphics::FromImage(pictureBox1->Image);		// in Form1_Load


		g_bmpPicBox2 = gcnew Bitmap(gLx, gLy);
		pictureBox2->Image = g_bmpPicBox2;  // in Form1_Load
		_Grph2 = Graphics::FromImage(pictureBox2->Image);		// in Form1_Load
	
		 
		// 真ん中に表示します
		WindowToCenter();


		// ペン色などの設定
		penRed = gcnew Pen(Color::Red, 1);
		pen_PV_Red = gcnew Pen(Color::PaleVioletRed, 1);
		penWhite = gcnew Pen(Color::White, 1);
		penGlay = gcnew Pen(Color::DarkGray, 1);
		penYellow = gcnew Pen(Color::Yellow, 1);
		penLightBlue = gcnew Pen(Color::LightBlue, 1);

		penDimGray_Dot = gcnew Pen(Color::DimGray, 1);
		penDimGray_Dot->DashStyle = System::Drawing::Drawing2D::DashStyle::Dot;

		penDimGray_Dash = gcnew Pen(Color::DimGray, 1);
		penDimGray_Dash->DashStyle = System::Drawing::Drawing2D::DashStyle::Dash;

		penEquator = gcnew Pen(Color::Maroon, 2);
		penLongitude = gcnew Pen(Color::CadetBlue, 1);
		penLatitude = gcnew Pen(Color::CadetBlue,1);

		penDownTrail = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), CGPCommon::trailThickness);

		penDownTrail1 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 1);
		penDownTrail2 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 2);
		penDownTrail3 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 3);
		penDownTrail4 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 4);
		penDownTrail5 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 5);
		penDownTrail6 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 6);
		penDownTrail7 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 7);
		penDownTrail8 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 8);
		penDownTrail9 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 9);
		penDownTrail10 = gcnew Pen(Color::FromArgb(100, Color::LimeGreen), 10);
		  
		penUpTrail = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), CGPCommon::trailThickness);

		penUpTrail1 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 1);
		penUpTrail2 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 2);
		penUpTrail3 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 3);
		penUpTrail4 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 4);
		penUpTrail5 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 5);
		penUpTrail6 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 6);
		penUpTrail7 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 7);
		penUpTrail8 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 8);
		penUpTrail9 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 9);
		penUpTrail10 = gcnew Pen(Color::FromArgb(100, Color::SkyBlue), 10);
		 
		//Color::FromArgb(150, Color::LightGreen);
		 
		penSeaLine = gcnew Pen(Color::DarkOliveGreen, 2);

		fntL = gcnew System::Drawing::Font("Arial", 14);
		fntM = gcnew System::Drawing::Font("Arial", 10);
		fntS = gcnew System::Drawing::Font("Arial", 8);
		fntXS = gcnew System::Drawing::Font("Arial", 7);

		brYellow = gcnew SolidBrush(Color::YellowGreen);
		brMagenta = gcnew SolidBrush(Color::Magenta);
		brWhite = gcnew SolidBrush(Color::LightGray);
		brBlue = gcnew SolidBrush(Color::LightBlue);
		brGray = gcnew SolidBrush(Color::DimGray);
		brRed = gcnew SolidBrush(Color::Red);

		brLand1 = gcnew SolidBrush(Color::SaddleBrown);
		brLand2 = gcnew SolidBrush(Color::DarkOliveGreen);
		brLand3 = gcnew SolidBrush(Color::DarkSlateBlue);
		brLand4 = gcnew SolidBrush(Color::DimGray);
		brLand5 = gcnew SolidBrush(Color::DarkSlateGray);

		if (CGPCommon::IsDemoMode == 0) {
			//デモなし
			this->buttonDemoStart->Visible = false;
			this->progressBar1->Visible = false;
		}
		else {
			this->buttonDemoStart->Visible = true;
			this->progressBar1->Visible = true;
		}



		/////////////////////////////////////////
		// スレッドセーフ用クリティカルセクション
		// クリティカルセクションの初期化
		//////////////////////////////////////////

		InitializeCriticalSection(&gCS);


		gMaxSize_multimap = CGPCommon::_mltMapTrail.max_size();

		CGPCommon::_mapFlightCode.clear();


		this->fileSystemWatcher1->Path = gcnew String(CGPCommon::_strDataFolder.c_str());


		/////////////////////
		// 開始音 チャイム　
		/////////////////////
		System::Media::SoundPlayer^ p = gcnew System::Media::SoundPlayer(SOUND_FILE);
		p->Play();



	}


	private: System::Void sub_ReadSystemParam() {

		//日時の認識
		DateTime now = DateTime::Now;
		String^ Str_yyyyMMdd = now.ToString("yyyy-MMdd");

		/////////////////////////////////////
		// システムパラメータの読み込み
		/////////////////////////////////////
		std::vector<std::vector<std::string > > vec_vec_strTable;
		vec_vec_strTable.clear();
		MngFnc::LoadCsvFileSkipHeader1(gSystemParamFile, vec_vec_strTable);

		int num = vec_vec_strTable.size();

		CGPCommon::_vecSystemParam.clear();

		for (int i = 0; i < num; i++) {
			std::vector<std::string > vecString = vec_vec_strTable[i];
			int num2 = vecString.size();

			if (num2 < 5) {
				// if ( num2<5 ){
				break;
			}

			CGPCommonDefinition::SystemParam pd;

			pd.CODE.append(vecString[0].c_str());		// S001とかいうコード
			pd.NAME.append(vecString[1].c_str());		// 名称
			pd.MIN_VALUE = atoi(vecString[2].c_str());	//MIN
			pd.MAX_VALUE = atoi(vecString[3].c_str());	//MAX
			pd.VALUE = atoi(vecString[4].c_str());		//VALUE（設定値）

			CGPCommon::_vecSystemParam.push_back(pd);

		}


		//////////////////////////////////////////////////
		//　パラメータの起動時読み込み、更新場所はここで
		//  ２箇所のうちの一つ
		//////////////////////////////////////////////////
		CGPCommon::UpdateSystemParam();

		//文字パラメータの読み込み
		//　特に、データフォルダの設定
		vec_vec_strTable.clear();
		MngFnc::LoadCsvFileSkipHeader1(STRING_PARAM_FILE, vec_vec_strTable);  // StringParameters.csv
		num = vec_vec_strTable.size();

		for (int i = 0; i < num; i++) {

			std::vector<std::string > vecString = vec_vec_strTable[i];
			int num2 = vecString.size();

			if (num2 < 2) {
				break;
			}

			if (!strcmp(vecString[0].c_str(), "DATA_FOLDER")) {
				String^ Str = gcnew String(vecString[1].c_str());
				CGPCommon::_strDataFolder = vecString[1];

				//this->textBoxImageFolder->Text = Str;
			}
			else if (!strcmp(vecString[0].c_str(), "LOG_FOLDER")) {

				std::string strLog = vecString[1].c_str();

				std::string str_yyyyMMdd;
				MngFnc::String_to_string(Str_yyyyMMdd, str_yyyyMMdd);
				strLog.append("\\Log_").append(str_yyyyMMdd).append(".csv");

				CGPCommon::strLogFileWithFullPath = strLog;
			}
		}


		////////////////////////////////
		//データグリッドへの登録
		////////////////////////////////
		this->dataGridViewSystemParamTable->Rows->Clear();  //全行クリアします

		num = CGPCommon::_vecSystemParam.size();

		for (int i = 0; i < num; i++) {

			SystemParam up = CGPCommon::_vecSystemParam[i];

			this->dataGridViewSystemParamTable->Rows->Add();  //まず、一行空で追加します。

			String^ Str = gcnew String(up.CODE.c_str());   // char-->Stirng 変換の技
			String^ Str2 = gcnew String(up.NAME.c_str());  // char-->Stirng 変換の技
			this->dataGridViewSystemParamTable->Rows[i]->Cells[0]->Value = Str2;
			this->dataGridViewSystemParamTable->Rows[i]->Cells[1]->Value = Convert::ToString(up.MIN_VALUE) + "～" + Convert::ToString(up.MAX_VALUE);
			this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value = Convert::ToString(up.VALUE);

		}


		// 簡易ダーティーチェック
		CGPCommon::strFormerForSystemParamDirtyCheck.clear();

		int rowCount = this->dataGridViewSystemParamTable->RowCount;

		for (int i = 0; i < rowCount; i++) {
			String^ Str = (String^)this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value;

			std::string str;
			MngFnc::String_to_string(Str, str);
			CGPCommon::strFormerForSystemParamDirtyCheck.append(str);
		}


	}

	private: System::Void pictureBox1_MouseDown(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {

		int x = e->Location.X;
		int y = e->Location.Y;

		//MessageBox::Show(x.ToString() + "/" + y.ToString());


		int size = CGPCommon::_mapDispPos.size();

		std::map<std::string, CGPCommonDefinition::DispPos2D>::iterator it;

		std::string strHex;
		//std::string strFlight;
		double minLen = 10000;

		for (it = CGPCommon::_mapDispPos.begin(); it != CGPCommon::_mapDispPos.end(); it++) {

			std::string strKey = it->first;							// イテレータからキーが得られる。
			CGPCommonDefinition::DispPos2D P2d = it->second;		// イテレータから値が得られる。

			double d = sqrt((x - P2d.X) * (x - P2d.X) + (y - P2d.Y) * (y - P2d.Y));
			if (d < minLen) {
				minLen = d;
				strHex = strKey;
				//strFlight = strKey;
			}
		}

		if (minLen > 50) {

			//見つからない

			CGPCommon::strHex_pointing_Now.clear();

			numericUpDown1->Enabled = true;  

		}
		else {
			String^ S1 = gcnew String(strHex.c_str());
		    
			CGPCommon::strHex_pointing_Now = strHex; 

			CGPCommon::TimerInterval = 0;  //2023-12-04 ???

			numericUpDown1->Enabled = false; //角度は自動設定されるので。
		}

		bIsGenerateMap = true;

		numericUpDown1_ValueChanged(sender, e);

		return;

	}


	private: System::Void buttonRenew_Click(System::Object^ sender, System::EventArgs^ e) {

		////////////////////////////////////////
		// パラメータの更新ボタンが押されたとき
		////////////////////////////////////////

		int Count = this->dataGridViewSystemParamTable->RowCount;

		//パラメータの整合性の確認
		for (int i = 0; i < Count; i++) {

			SystemParam up = CGPCommon::_vecSystemParam[i];

			try {
				int Val = Convert::ToInt32(this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value);
				if ((up.MIN_VALUE > Val) || (up.MAX_VALUE < Val)) {
					String^ Str;
					Str = Convert::ToString(i + 1) + "番目の変数範囲が誤っています。";

					MessageBox::Show(Str, "確認");

					return;

				}
			}
			catch (Exception^ exception) //例外処理
			{
				exception;//warning C4101を消します。（意味なしの行）
				String^ Str;
				Str = Convert::ToString(i + 1) + "番目の変数範囲が誤っています。";

				MessageBox::Show(Str, "確認");

				return;
			}

		}

		for (int i = 0; i < Count; i++) {
			CGPCommon::_vecSystemParam[i].VALUE = Convert::ToInt32(this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value);
		}

		std::vector<std::vector<std::string > > vec_vec_strTable;

		for (int i = 0; i < Count; i++) {

			SystemParam up = CGPCommon::_vecSystemParam[i];

			std::vector<std::string > vec_str;
			char cMin[20];
			char cMax[20];
			char cValue[20];

			sprintf(cMin, "%-d", up.MIN_VALUE);
			sprintf(cMax, "%-d", up.MAX_VALUE);
			sprintf(cValue, "%-d", up.VALUE);
			vec_str.push_back(up.CODE); //S001とか
			vec_str.push_back(up.NAME); //
			vec_str.push_back(cMin);	// stringでなくても大丈夫
			vec_str.push_back(cMax);	// stringでなくても大丈夫
			vec_str.push_back(cValue);	// stringでなくても大丈夫

			vec_vec_strTable.push_back(vec_str);
		}

		//CSVファイルへ書き込み
		MngFnc::SaveCsvParameterFile(gSystemParamFile, vec_vec_strTable);

		// 簡易ダーティーチェック
		CGPCommon::strFormerForSystemParamDirtyCheck.clear();

		int rowCount = this->dataGridViewSystemParamTable->RowCount;

		for (int i = 0; i < rowCount; i++) {
			String^ Str = (String^)this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value;

			std::string str;
			MngFnc::String_to_string(Str, str);

			CGPCommon::strFormerForSystemParamDirtyCheck.append(str);
		}

		//////////////////////////////////////////////////
		//　パラメータの起動時読み込み、更新場所はここで
		//  ２箇所のうちの一つ
		//////////////////////////////////////////////////

		CGPCommon::UpdateSystemParam();

		//文字パラメータの読み込み
		//　特に、データフォルダの設定
		vec_vec_strTable.clear();
		MngFnc::LoadCsvFileSkipHeader1(STRING_PARAM_FILE, vec_vec_strTable);  // StringParameters.csv
		int num = vec_vec_strTable.size();

		for (int i = 0; i < num; i++) {

			std::vector<std::string > vecString = vec_vec_strTable[i];
			int num2 = vecString.size();

			if (num2 < 2) {
				break;
			}

			if (!strcmp(vecString[0].c_str(), "DATA_FOLDER")) {
				String^ Str = gcnew String(vecString[1].c_str());
				CGPCommon::_strDataFolder = vecString[1];

			}

		}

	}

	private: System::Void buttonExplorer_Click(System::Object^ sender, System::EventArgs^ e) {

		//データフォルダを開く
		String^ StrDir = gcnew String(CGPCommon::_strDataFolder.c_str());
		System::Diagnostics::Process::Start("explorer", StrDir);

		//MessageBox::Show(StrDir);
		//OK System::Diagnostics::Process::Start("explorer", "c:\\tmp");	

	}

	private: System::Void Form1_MouseWheel(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {

	}


	private: System::Void Form1_FormClosed(System::Object^ sender, System::Windows::Forms::FormClosedEventArgs^ e) {

		//メモリ後しまつ	
		// 
		// 


		//////////////////////////////////////////
		//スレッドセーフ用クリティカルセクション
		//クリティカルセクションの消去
		//////////////////////////////////////////

		DeleteCriticalSection(&gCS);

	}

		   int calc_dist_dir(double idoA, double keidoA, double idoB, double keidoB, double& distABkm, double& dir_ABdeg) {

			   // 地球表面の２点A,B　Aから見たBの距離と向き
			   //

			   if ((idoA == idoB) && (keidoA == keidoB)) {
				   distABkm = 0;
				   dir_ABdeg = 0;
				   return(1);
			   }

			   double D2R = PI / 180.0;
			   double Rkm = 6378.137;	// *1000;  //地球半径kmｍ

			   Vct3 vON(0, 0, 1);
			   Vct3 vOA, vOB;

			   Mat3 MAi, MAk;
			   Mat3 MBi, MBk;

			   {
				   MAi.set_axis_y_rot(-idoA);
				   MAk.set_axis_z_rot(keidoA);

				   MBi.set_axis_y_rot(-idoB);
				   MBk.set_axis_z_rot(keidoB);

				   Vct3 vX(1, 0, 0);

				   vOA = MAk * (MAi * vX);
				   vOB = MBk * (MBi * vX);
			   }

			   double cosW = (vOA | vOB);		  //ベクトル内積
			   distABkm = Rkm * (acos(cosW));	  //弧長距離

			   bool b_isOA_eq_NS = vOA.is_parallel_to(vON);

			   if (b_isOA_eq_NS == false) {
				   //Aは、極点でないとき
				   Vct3 vAF = vOB - (vOA | vOB) * vOA;
				   Vct3 vAE = vON - (vOA | vON) * vOA;

				   double cosT = (vAF | vAE) / (vAF.length() * vAE.length());    //ベクトル内積

				   if (cosT >= 1.0) {
					   cosT = 1.0;
				   }
				   else if (cosT < -1.0) {
					   cosT = -1.0;
				   }

				   double degT = (acos(cosT)) / D2R;  // 0---180

				   // N方向を0°で時計回りに0～360°とするため。
				   if ((vAF ^ vAE | vOA) >= 0) {  
					   dir_ABdeg = +degT;
				   }
				   else {
					   dir_ABdeg = -degT;
				   }
			   }
			   else {
				   // Aは、NかS極のとき（vONに並行のとき）
				   if ((vOA | vON) > 0) {
					   //AはN極
					   dir_ABdeg =-keidoB;
				   }
				   else {
					   //AはS極
					   dir_ABdeg =+ keidoB; 
				   }
			   }
			    
			   // 飛行機の向きを、0～359度に調整します
			   if (dir_ABdeg < 0) {
				   dir_ABdeg = dir_ABdeg + 360.0;
			   }

			   return(0);
		   }


		   int set_ADS(String^ Spath, std::vector<strct_ADS >& vec_ADS) {

				//    Hex     Mode  Sqwk  Flight   Alt    Spd  Hdg    Lat      Long   Sig  Msgs Ti
				//	------------------------------------------------------------------------------
				//	86D2CC  S     3316  ANA18     6175  203  335   35.160  140.203   10  2336    1
				//	841B6A  S     0442  SFJ43    27050  350  265   35.463  138.885    6  1473    0
				//	8422F9  S     2212  JAL184    4275  181  300   35.268  140.026   34  3781    0
				//	84B772  S     3361  ANA396    3125  186  330   35.417  139.892   15  8432    1
				//  8511CA  S                    13250  346  042                      4     2   49 

				//   羽田空港 緯度: 35.5554　 経度: 139.7544
				//　 地球半径 6378.1ｋｍ
			   
				// Hex
				//   ICAO 24bit codeの16進数表現
				// Mode
				//  （ふつうはS）
				// Sqwk
				//  スコーク(Squawk)コード
				//  7500:ハイジャック、7600:無線機故障、7700:緊急事態
				// Flight
				//  フライト名(便名)
				// Alt
				//  高度[ft]
				// Spd
				//  対地速度[NM/h]
				// Hdg
				//  ヘディング(航空機が向いている方向)[度]
				// Lat
				//  緯度
				// Long
				//  経度
				// RSSI
				//  信号強度
				// Msgs
				//  当該航空機から受信したADS-Bメッセージ数
				// Ti
				//  当該航空機から最後に受信したメッセージからの経過時間[秒]
 
			   std::vector<std::vector<std::string > >  vec_vec_strTable;

			   MngFnc::LoadCsvFileWithHeader(Spath, vec_vec_strTable);

			   int nL = vec_vec_strTable.size();

			   for (int i = 0; i < nL; i++) {

				   strct_ADS ADS;

				   std::vector<std::string > vecString = vec_vec_strTable[i];
				   std::string str1 = vecString[0];

				   char cbuf[256], cFlight[10], cAlt[10], cSpd[10], cHeadDirection[10], cLat[10], cLong[10], cTi_sec[10];

				   strcpy(cbuf, str1.c_str());


				   //2023-12-27 HEX追加
				   char cHex[7];
				   strncpy(cHex, cbuf, 6);
				   cHex[6] = 0;
				   ADS.strHex.append("[").append(cHex).append("]");

				   cFlight[7] = 0;
				   strncpy(cFlight, &cbuf[21 - 1], 7);
				   cFlight[7] = 0; cFlight[8] = 0; cFlight[9] = 0;
				   ADS.strFligtNumber.append(cFlight);


				   cAlt[5] = 0;
				   strncpy(cAlt, &cbuf[30 - 1], 5);
				   if (!std::strncmp(cAlt, " grnd", 5)) {
					   ADS.Alt_feet = 1;
					   //MngFnc::WriteCsvLog("On the Ground now ");
				   }
				   else {
					   ADS.Alt_feet = atof(cAlt);
				   }

				   cSpd[3] = 0;
				   strncpy(cSpd, &cbuf[37 - 1], 3);
				   ADS.Spd_mile = atof(cSpd);

				   cHeadDirection[3] = 0;
				   strncpy(cHeadDirection, &cbuf[42 - 1], 3);
				   ADS.HeadDirection = atof(cHeadDirection);

				   cLat[7] = 0;
				   strncpy(cLat, &cbuf[47 - 1], 7);
				   ADS.Lat = atof(cLat);

				   cLong[7] = 0;
				   strncpy(cLong, &cbuf[56 - 1], 7);
				   ADS.Long = atof(cLong);

				   cTi_sec[5] = 0;
				   strncpy(cTi_sec, &cbuf[76 - 1], 5);
				   ADS.Ti_sec = atof(cTi_sec);

				   if (ADS.Long < 0) {
					   ADS.Long = ADS.Long + 180;   // -40  ---> 140　の例があったので。
				   }

				   if (ADS.strHex.compare(0, 1, " ") && ADS.Spd_mile > 0 && ADS.Lat > 0) { 
					   if (ADS.Alt_feet >= 0) {
						   vec_ADS.push_back(ADS);
					   }
				   }

			   }

			   return(0);
		   }

		   // 斜めから見た斜視図　もしくは、平面図
		   int PlotPlanes_3D_or_Horiz(
			   std::vector<strct_ADS >  vec_ADS,
			   double ang1, 						//視線方向1(平面：0度～立面：90度）    
			   double Radius_km 					//対象半径
		   )
		   {

			   Vct2 O1, p1, p2, p3, p4, p5, p6;

			   Vct2 Ex(1, 0);
			   Vct2 Ey(0, 1);

			   double idoA;
			   double keidoA;
			   String^ S_LocName;

			   double alt_m_former, idoB_former, keidoB_former;  //2025-10-29

			   gPlaneNum = vec_ADS.size();
			   
			   CGPCommon::_mapDispPos.clear();

			   int iLM = max(this->listBoxKijyunLoc->SelectedIndex,0);
	 
			   int DispKind_ex = CGPCommon::nDispKind;


			   if (CGPCommon::strHex_pointing_Now.size() == 0) {

				   // 飛行機がマウス選択されていないとき
				   //
				   idoA = CGPCommon::_vec_LandMarks[iLM].ido;
				   keidoA = CGPCommon::_vec_LandMarks[iLM].keido;
				   S_LocName = gcnew String(CGPCommon::_vec_LandMarks[iLM].strLongName.c_str());

				   if (gRadius_km > 300) {

					   // 縮尺が大きいときは、飛行機表示しない
					   // 0 or 1になり、ランドマーク表示のOn/Offを意味します
					   DispKind_ex = CGPCommon::nDispKind % 2;
				   }
			   }
			   else if (CGPCommon::strHex_pointing_Now.size() > 0) {
				   
				   // 飛行機がマウス選択されているとき
				   // その飛行機を中心にします
				   int PlaneNum;

				   if (DispKind_ex / 2 == 0) {
					   //飛行機表示をしないとき
					   PlaneNum = 0;
				   }
				   else {
					   PlaneNum = vec_ADS.size();
				   }

				   for (int i = 0; i < PlaneNum; i++) {

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {
						 
						   strct_ADS ADS = vec_ADS[i];

						   if (ADS.Lat == 0 && ADS.Long == 0) {
							   return(1); //変だ
						   }

						   idoA = ADS.Lat;
						   keidoA = ADS.Long;
						   S_LocName = gcnew String(ADS.strFligtNumber.c_str());

						   gROUND_DEG = -ADS.HeadDirection;

						   bIsGenerateMap = true;

						   goto NEXT_1;

					   }
				   }

				   CGPCommon::TimerInterval = CGPCommon::TimerInterval + 1;

				   if (CGPCommon::TimerInterval > 4*10) {   // 10秒すぎたら
						
					   CGPCommon::strHex_pointing_Now.clear();

					   for (int i = 0; i < PlaneNum; i++) {
						   if (vec_ADS[i].strFligtNumber.compare(0, 1, " ")) {
							   // " "でない＝フライトNoが存在する
							   CGPCommon::strHex_pointing_Now = vec_ADS[i].strHex;
							   goto NEXT100;
						   }

					   }

				   NEXT100:
					   ;
				   }

				   // 見つからないときは、抜ける
				   return(1);

			   }


		   NEXT_1:

			   //////////////////////////////////////
			   // 航空機位置をマルチマップに登録
			   //////////////////////////////////////
			   for (int i = 0; i < vec_ADS.size(); i++) {

				   CGPCommonDefinition::strct_Trail trail;
				   trail.Counter = gCnt;
				   trail.Alt_m = vec_ADS[i].Alt_feet * 0.305;
				   trail.Lat = vec_ADS[i].Lat;			//緯度
				   trail.Long = vec_ADS[i].Long;		//経度 
				   trail.Ti_sec = vec_ADS[i].Ti_sec;	//

				   CGPCommon::_mltMapTrail.insert(std::pair<std::string, CGPCommonDefinition::strct_Trail>(vec_ADS[i].strHex, trail));

				   CGPCommon::_mapFlightCode[vec_ADS[i].strHex] = vec_ADS[i].strFligtNumber;
			   }

			   
			   // ランドマークの登録数
			   int NumLandMarks = CGPCommon::_vec_LandMarks.size();

			   // 大陸や島の登録数
			   int NumSeaLine = CGPCommon::_vec_vec_SeaLine.size();


			   int PlaneNum;

			   if (DispKind_ex / 2 == 0) {
				   //飛行機表示をしないとき
				   PlaneNum = 0;
			   }
			   else {
				   PlaneNum = vec_ADS.size();
			   }

			   short OFSY = 100;

			   Mat2 M_gR;
			   M_gR.set_axis_rot(-gROUND_DEG);

			   double Fact = 0.8;

			   double FactH = Fact / 2;


			   short DX = gLx * Fact;
			   short DY = gLx * Fact * cos(ang1 * PI / 180.0);


			   std::vector<std::vector<POINT>> vec_vec_POINT;
			   std::vector<POINT> vec_POINT;


			   if ((gROUND_DEG == gROUND_DEG_former) && (gDEPRS_DEG == gDEPRS_DEG_former) && (gRadius_km == gRadius_km_former) && (bIsGenerateMap == false)) {
				   
				   //直前と同じなので、地図を描く必要はありません
				   goto JUMP_TO_TRAIL;

			   }
			   else {

				   //地図情報を、pictureBox2に書き込みます
				   _Grph2->Clear(System::Drawing::Color::MidnightBlue);

			   }


			   ////////////////////////////
			   //　海岸線　Sea Line
			   ////////////////////////////

			   int X1, X2, Y1, Y2;

			   for (int i = 0; i < NumSeaLine; i++) {

				   //閉曲線単位（大陸、島など）

				   int Num_sea_points = CGPCommon::_vec_vec_SeaLine[i].size();

				   std::vector<DispPos2D > vecDP;

				   bool bIsAllIn = true;
				   bool bIsAllOut = true;

				   double max_km = 0;

				   for (int j = 0; j < Num_sea_points; j++) {

					   double idoB = (CGPCommon::_vec_vec_SeaLine[i])[j].ido;
					   double keidoB = (CGPCommon::_vec_vec_SeaLine[i])[j].keido;

					   double distABkm, dirABdeg;

					   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);

					   if (distABkm > max_km) {
						   max_km = distABkm;
					   }


					   Mat2 M_dirAB;

					   M_dirAB.set_axis_rot(-dirABdeg);

					   Vct2 Wa(0, 1);

					   Vct2 Wb = distABkm * ((M_gR * M_dirAB) * Wa);

					   X2 = gLx / 2 + FactH * gLx / Radius_km * Wb.x;
					   Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * Wb.y;


					   if (j > 0) {

						   bool bP1in = (0 < X1 && X1 < (gLx-1)) && (0 < Y1 && Y1 < (gLy-1));
						   bool bP2in = (0 < X2 && X2 < (gLx-1)) && (0 < Y2 && Y2 < (gLy-1));

						   if (bP1in == true && bP2in == true) {

							   // (X1,Y1),(X2,Y2)は、表示領域の内部
							   if (j > 0) {
								   _Grph2->DrawLine(penSeaLine, X1, Y1, X2, Y2);
							   }

							   bIsAllOut = false;
						   }
						   else {
							   bIsAllIn = false;
						   }
					   }

					   X1 = X2;
					   Y1 = Y2;

					   DispPos2D DP;
					   DP.X = X2;
					   DP.Y = Y2;
					   vecDP.push_back(DP);
				   }

				   if (CGPCommon::nuritsubushi > 0 && (max_km < 19900)) {
					 
					   SolidBrush^ brLand;

					   if (CGPCommon::nuritsubushi == 1) {
						   brLand = brLand1;
					   }
					   else if (CGPCommon::nuritsubushi == 2) {
						   brLand = brLand2;
					   }
					   else if (CGPCommon::nuritsubushi == 3) {
						   brLand = brLand3;
					   }
					   else if (CGPCommon::nuritsubushi == 4) {
						   brLand = brLand4;
					   }
					   else if (CGPCommon::nuritsubushi == 5) {
						   brLand = brLand5;
					   }


					   if (bIsAllIn == true) {

						   //閉曲線が窓に包含されている場合

						   array<Point>^ ArrayPoint = gcnew array<Point>(vecDP.size());

						   for (int j = 0; j < ArrayPoint->Length; j++) {

							   Point P;
							   P.X = vecDP[j].X;
							   P.Y = vecDP[j].Y;

							   ArrayPoint[j] = P;
						   }

						   _Grph2->FillPolygon(brLand, ArrayPoint);

					   }
					   else if (bIsAllOut == false) {

						   //閉曲線と窓でクリッピング処理が必要な場合

						   std::vector<std::vector<DispPos2D >>  vec_vec_DP2;

						   int ier = sub_Clipping(vecDP, vec_vec_DP2);

						   if (ier == -1) {
							   //（ここは通らない）
							   goto JUMP_0;  //この閉曲線は、処理しない
						   }
						   else if (ier == -2) {
							   //　閉曲線が窓に１点で接している可能性がある
							   //

							   array<Point>^ ArrayPoint = gcnew array<Point>(vecDP.size());

							   for (int j = 0; j < ArrayPoint->Length; j++) {

								   Point P;
								   P.X = vecDP[j].X;
								   P.Y = vecDP[j].Y;

								   ArrayPoint[j] = P;
							   }

							   _Grph2->FillPolygon(brLand, ArrayPoint);
						   }
						   else {
							   
							   //普通は、ここを通る

							   int num1 = vec_vec_DP2.size();

							   for (int i = 0; i < num1; i++) {

								   std::vector<DispPos2D > vecDP2;

								   vecDP2 = vec_vec_DP2[i];

								   array<Point>^ ArrayPoint2 = gcnew array<Point>(vecDP2.size());

								   for (int j = 0; j < ArrayPoint2->Length; j++) {

									   Point P;
									   P.X = vecDP2[j].X;
									   P.Y = vecDP2[j].Y;

									   ArrayPoint2[j] = P;
								   }

								   _Grph2->FillPolygon(brLand, ArrayPoint2);
							   }
						   }
					   }
				   }

			   JUMP_0:
				   ;

			   }


			   /////////////////////////
			   //  地図の補助線　
			   //   補助円表示(0=非表示/1=細線/2=赤線（メモリ付き））
			   /////////////////////////
		 
			   if (CGPCommon::hojyoenNo == 2) {

				   _Grph2->DrawEllipse(pen_PV_Red, (gLx - DX) / 2, (gLy - DY) / 2, DX, DY);

				   _Grph2->DrawEllipse(penDimGray_Dash, (gLx - DX) / 2 + DX / 4, (gLy - DY) / 2 + DY / 4, DX / 2, DY / 2);


				   for (int i = 0; i < 360; i = i + 5) {

					   Vct2 V_N(0, 1);
					   Mat2 M_gR;
					   M_gR.set_axis_rot(-gROUND_DEG - i);


					   Vct2 W_N = Radius_km * M_gR * V_N;

					   Vct2 P0, P1, P2, P3;

					   short X1 = gLx / 2;
					   short Y1 = gLy / 2;

					   short X2 = gLx / 2 + FactH * gLx / Radius_km * W_N.x;
					   short Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * W_N.y;

					   P0.set(X1, Y1);
					   P2.set(X2, Y2);

					   double t = 0.97;

					   if (i % 90 == 0) {
						   t = 0.95;
					   }
					   P1 = P0 + t * (P2 - P0);

					   _Grph2->DrawLine(pen_PV_Red, (short)P1.x, (short)P1.y, (short)P2.x, (short)P2.y);

					   P3 = P2 + 0 * (P2 - P0) / (P2 - P0).length();  //少し外側に、N,E,S,Wを記す

					   if (i == 0) {
						   _Grph2->DrawString("N" + " " + Radius_km.ToString("###") + "km", fntL, brWhite, (short)P3.x, (short)P3.y);
					   }
					   else if (i == 90) {
						   _Grph2->DrawString("E" + " " + Radius_km.ToString("###") + "km", fntL, brWhite, (short)P3.x, (short)P3.y);

					   }
					   else if (i == 180) {
						   _Grph2->DrawString("S", fntL, brWhite, (short)P3.x, (short)P3.y);

					   }
					   else if (i == 270) {
						   _Grph2->DrawString("W", fntL, brWhite, (short)P3.x, (short)P3.y);

					   }
				   }

			   }
			   else if (CGPCommon::hojyoenNo == 1) {

				   _Grph2->DrawEllipse(penDimGray_Dash, (gLx - DX) / 2, (gLy - DY) / 2, DX, DY);

				   _Grph2->DrawEllipse(penDimGray_Dash, (gLx - DX) / 2 + DX / 4, (gLy - DY) / 2 + DY / 4, DX / 2, DY / 2);

			   }

			   /////////////////////
			   //  緯線（含む、赤道)
			   /////////////////////		   
			   if (CGPCommon::IsEquator == 1) {

				   int X1, X2, Y1, Y2;
				   int N = 360;

				   for (int k =-180; k < 180; k = k + 15) {

					   for (int j = 0; j <= N; j++) {

						   double idoB = k;  // 0.0;
						   double keidoB = j * (360 / N);

						   double distABkm, dirABdeg;

						   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);

						   Mat2 M_dirAB;

						   M_dirAB.set_axis_rot(-dirABdeg);

						   Vct2 Wa(0, 1);

						   Vct2 Wb = distABkm * ((M_gR * M_dirAB) * Wa);

						   X2 = gLx / 2 + FactH * gLx / Radius_km * Wb.x;
						   Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * Wb.y;

						   if (j > 0) {

							   bool bP1in = (0 < X1 && X1 < (gLx - 1)) && (0 < Y1 && Y1 < (gLy - 1));
							   bool bP2in = (0 < X2 && X2 < (gLx - 1)) && (0 < Y2 && Y2 < (gLy - 1));

							   if (bP1in == true && bP2in == true) {

								   if (k == 0) {
									   //赤道
									   _Grph2->DrawLine(penEquator, X1, Y1, X2, Y2);
								   }
								   else {
									   //緯線
									   _Grph2->DrawLine(penLatitude, X1, Y1, X2, Y2);
								   }
							   }

						   }

						   X1 = X2;
						   Y1 = Y2;
					   }

				   }
			   }


			   /////////////
			   //  経線
			   /////////////
			   if (CGPCommon::IsKEISEN == 1) {

				   int X1, X2, Y1, Y2;
				   int N = 360;

				   for (int k = 0; k < 360; k = k + 15) {
					   
					   double keidoB = k;

					   for (int j = 0; j <= N; j++) {

						   double idoB = j * (360 / N);
						  
						   double distABkm, dirABdeg;

						   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);

						   Mat2 M_dirAB;

						   M_dirAB.set_axis_rot(-dirABdeg);

						   Vct2 Wa(0, 1);

						   Vct2 Wb = distABkm * ((M_gR * M_dirAB) * Wa);

						   X2 = gLx / 2 + FactH * gLx / Radius_km * Wb.x;
						   Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * Wb.y;

						   if (j > 0) {

							   bool bP1in = (0 < X1 && X1 < (gLx - 1)) && (0 < Y1 && Y1 < (gLy - 1));
							   bool bP2in = (0 < X2 && X2 < (gLx - 1)) && (0 < Y2 && Y2 < (gLy - 1));

							   if (bP1in == true && bP2in == true) {
								   _Grph2->DrawLine(penLongitude, X1, Y1, X2, Y2);
							   }

						   }

						   X1 = X2;
						   Y1 = Y2;
					   }
				   }

			   }

			   /////////////////////
			   //  ランドマーク 
			   /////////////////////
			   if (DispKind_ex % 2 == 1) {


				   for (int i = 0; i < NumLandMarks; i++) {

					   double idoB = CGPCommon::_vec_LandMarks[i].ido;
					   double keidoB = CGPCommon::_vec_LandMarks[i].keido;
					   String^ S_LocNameB = gcnew String(CGPCommon::_vec_LandMarks[i].strLongName.c_str());
					   int rank = CGPCommon::_vec_LandMarks[i].rank;

					   double distABkm, dirABdeg;

					   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);


					   // ランドマークのランクで、表示するか、を判断
					   if (3000 < gRadius_km) {
						   if (rank >= 2) {
							   continue;
						   }
					   }
					   else if (300.0 < gRadius_km) {
						   if (rank >= 3) {
							   continue;
						   }
					   }

					   Mat2 M_dirAB;

					   M_dirAB.set_axis_rot(-dirABdeg);

					   Vct2 Wa(0, 1);

					   Vct2 Wb = distABkm * ((M_gR * M_dirAB) * Wa);

					   short X2 = gLx / 2 + FactH * gLx / Radius_km * Wb.x;
					   short Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * Wb.y;
					   short s;

					   if ((fabs(X2) > 0) && (fabs(Y2) > 0)){ 

						   if ((i == iLM) && (CGPCommon::strHex_pointing_Now.size() == 0)) {
							    
							   // 中心の航空機を赤く表示
							   s = 4;
							   _Grph2->DrawEllipse(penRed, X2 - s, Y2 - s, 2 * s, 2 * s);

						   }
						   else {
							   s = 3;
							   _Grph2->DrawRectangle(penLightBlue, X2 - s, Y2 - s, 2 * s, 2 * s);
						   }

						   _Grph2->DrawString(S_LocNameB, fntXS, brBlue, X2 + 3, Y2 + 3);
 
					   }

				   }
			   }

		   JUMP_TO_TRAIL:

			   gROUND_DEG_former = gROUND_DEG;
			   gDEPRS_DEG_former = gDEPRS_DEG;
			   gRadius_km_former = gRadius_km;
			   bIsGenerateMap = false;
 
			   // 
			   // 地図情報(pictureBox2)をコピーします
			   //

			   _Grph1->Clear(System::Drawing::Color::MidnightBlue);

			   _Grph1->DrawImage(pictureBox2->Image, 0, 0); 




			   //////////////////////////////////////////
			   //航空機の軌跡  in PlotPlanes_3D_or_Horiz
			   //////////////////////////////////////////

			   for (int i = 0; i < PlaneNum; i++) {

				   std::vector<double> vec1;
				   std::vector<double> vec2;

				   //int Cnt = CGPCommon::_mltMapTrail.count(vec_ADS[i].strHex.c_str()); 

				   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it;

				   //std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it2;

				   std::vector<Vct3 >vecAIK, vecAIK_w;

				   if ((CGPCommon::IsTrail == false)) {

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {

						   // （航空機の軌跡を描くモードではなくても）マウスクリックされていたら、その１機だけの軌跡を描きます。
						   ;
					   }
					   else {
						   //航空機の軌跡を描かないモードのときは、普通、ここを通ります。
						   goto JUMP1;
					   }

				   }
				   else {
					   //航空機の軌跡を描くモードのときは、ここを通ります。
					   ;
				   }

				   it = CGPCommon::_mltMapTrail.find(vec_ADS[i].strHex.c_str()); 

				   short iX, iY, iX_former, iY_former, iH_former;


				   // 離陸 or 着陸  最初と最後の高度差で判断
				   bool bIsLanding;

				   double alt1 = 0;
				   double alt2 = 0;

				   ////it2 = it;

				   // １飛行機の追跡線（飛行機雲）の線分数
				   int Cnt = CGPCommon::_mltMapTrail.count(vec_ADS[i].strHex.c_str());

				   it = CGPCommon::_mltMapTrail.find(vec_ADS[i].strHex.c_str());


				   for (int j = 0; j < Cnt; j++) {

					   double alt_m = (*it).second.Alt_m;
					   double idoB = (*it).second.Lat;
					   double keidoB = (*it).second.Long;

					   Vct3 AIK;
					   AIK.x = alt_m;
					   AIK.y = idoB;
					   AIK.z = keidoB;
					   vecAIK.push_back(AIK);

					   it++;

				   }


				   if (CGPCommon::trailMovingAverage_N > 0) {

					   // 移動平均

					   int N = CGPCommon::trailMovingAverage_N;

					   vecAIK_w = vecAIK;


					   for (int j = 0 + N; j < Cnt - N; j++) {

						   Vct3 AIK;

						   for (int k = -N; k <= N; k++) {

							   AIK = AIK + vecAIK_w[j + k];
						   }

						   AIK = AIK / (N * 2 + 1);

						   vecAIK[j] = AIK;
					   }

				   }

				   //////////////////////////////////////////
				   //航空機が、着陸態勢か否かを判断する
				   //////////////////////////////////////////
				   for (int j = 0; j < Cnt / 5; j++) {

					   double alt_m = vecAIK[j].x;

					   vec1.push_back(alt_m);

				   }

				   for (int j = 4 * (Cnt / 5); j < Cnt; j++) {

					   double alt_m = vecAIK[j].x;

					   vec2.push_back(alt_m);

				   }


				   // まれに発生するスパイクノイズを避けるため処理
				   std::sort(vec1.begin(), vec1.end());
				   std::sort(vec2.begin(), vec2.end());

				   if (vec1.size() > 5 && vec2.size() > 5) {
					   alt1 = vec1[vec1.size() / 2];
					   alt2 = vec2[vec2.size() / 2];
				   }
				   else if (vec1.size() > 0 && vec2.size() > 0) {
					   alt1 = vec1[0];
					   alt2 = vec2[0];
				   }
			  

				   if (alt1 > alt2) {
					   //着陸
					   bIsLanding = true;
				   }
				   else {
					   //離陸
					   bIsLanding = false;
				   }


				   for (int j = 0; j < Cnt; j++) {
					   //////std::cout << (*it).first.c_str() << " => " << (*it).second << '\n';

					   double alt_m = vecAIK[j].x;
					   double idoB = vecAIK[j].y;
					   double keidoB = vecAIK[j].z;

					   double distABkm, dirABdeg;

					   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);


					   Mat2 M_dirAB;

					   M_dirAB.set_axis_rot(-dirABdeg);

					   Vct2 Wa(0, 1);

					   // 航空機の座標や向きの計算用の回転行列　
					   // 　中心点からの角度、回転視野角度、航空機の向き
					   //
					   Vct2 Wb = distABkm * M_gR * M_dirAB * Wa;

					   short X2 = gLx / 2 + FactH * gLx / Radius_km * Wb.x;
					   short Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * Wb.y;

					   double b_a = (vec_ADS[i].HeadDirection - dirABdeg);


					   short s = 1;

					   if (ang1 >= 5.0) {

						   //斜視図

						   short iH;
						   if (CGPCommon::Height_exaggeration == 0) {
							   iH = sin(gDEPRS_DEG * D2R) * (FactH * gLx) * alt_m / (Radius_km * 1000.);
						   }
						   else {
							   iH = (FactH * gLx) * alt_m / (Radius_km * 1000.);
						   }
						   //241205 short iH = (FactH * gLx) * alt_m / (Radius_km * 1000.);

						   iX = X2 - s;
						   iY = Y2 - s - iH;


						   if (j > 0) {

							   // 軌跡の尾の長さ
							   if (j < (Cnt - CGPCommon::TailNo)) {
								   goto NEXT1; //nop
							   }

							   if ((iX == iX_former) && (iY == iY_former)) {
								   goto NEXT1; //nop
							   }

							   // まれに、航路が不連続になるときがあるので、排除します
							   bool bIsOK = (sqrt((iX - iX_former) * (iX - iX_former) + (iY - iY_former) * (iY - iY_former)) < D666);

							   if (bIsOK == true) {
						   
								   short penThick = CGPCommon::trailThickness;
								   //short penThick = CGPCommon::trailThickness * (double(j) / double(Cnt)) + 1;
								  
								   //斜視時
								   if (sqrt((idoB - idoB_former) * (idoB - idoB_former) + (keidoB - keidoB_former) * (keidoB - keidoB_former)) < 0.0099) {
								   //if ((idoB == idoB_former) && (keidoB == keidoB_former)) {
									   iX = iX_former;
									   iY = iY_former;

									   idoB = idoB_former;
									   keidoB = keidoB_former;
									   alt_m = alt_m_former;
								   }
								   else {
									   sub_Grph1_DrawTrail(bIsLanding, penThick, iX, iY, iX_former, iY_former);
								   }
							   

								   if (j == (Cnt - 1)) {
									   _Grph1->DrawLine(penDimGray_Dot, X2, Y2, X2, Y2 - iH);					//航空機の高度を示す垂直線
								   }

								   if (j % CGPCommon::Height_Line_Span == 0) {
									   _Grph1->DrawLine(penDimGray_Dot, X2, Y2, X2, Y2 - iH);					//航空機の高度を示す垂直線
								   }
							   }


						   NEXT1:
							   ;
						   }
						   iX_former = iX;
						   iY_former = iY;
						   iH_former = iH;

						   // 2025-10-29
						   idoB_former = idoB;
						   keidoB = keidoB_former; 
						   alt_m_former = alt_m;

					   }
					   else if (ang1 < 5) {

						   //平面図		

						   short iH;
						   if (CGPCommon::Height_exaggeration == 0) {
							   iH = sin(gDEPRS_DEG * D2R) * (FactH * gLx) * alt_m / (Radius_km * 1000.);
						   }
						   else {
							   iH = (FactH * gLx) * alt_m / (Radius_km * 1000.);
						   }
						   //241205 short iH = (FactH * gLx) * alt_m / (Radius_km * 1000.);

						   iX = X2 - s;
						   iY = Y2 - s;

						   if (j > 0) {

							   if ((iX == iX_former) && (iY == iY_former)) {
								   goto NEXT2; //nop
							   }

							   //軌跡の尾の長さ
							   if (j < (Cnt - CGPCommon::TailNo)) {
								   goto NEXT2; //nop
							   }

							   // まれに、航路が不連続になるときがあるので、排除します
							   bool bIsOK = (sqrt((iX - iX_former) * (iX - iX_former) + (iY - iY_former) * (iY - iY_former)) < D666);

							   if (bIsOK == true) {
								    
								   short penThick = CGPCommon::trailThickness;
								   //short penThick = CGPCommon::trailThickness * (double(j) / double(Cnt)) + 1;

								   //平面時
								   if ((idoB == idoB_former) && (keidoB == keidoB_former)) {
									   iX = iX_former;
									   iY = iY_former;
								   }
								   else {
									   sub_Grph1_DrawTrail(bIsLanding, penThick, iX, iY, iX_former, iY_former);
								   }
 
							   }

						   NEXT2:
							   ;
						   }
						   iX_former = iX;
						   iY_former = iY;
						   iH_former = iH;

						   // 2025-10-29
						   idoB_former = idoB;
						   keidoB = keidoB_former;
						   alt_m_former = alt_m;
					   }

					   //it++;

				   }
			   JUMP1:
				   ;
			   }

			   ///////////////////////////////////////////
			   // 航空機の描画 in PlotPlanes_3D_or_Horiz
			   ///////////////////////////////////////////

			   for (int i = 0; i < PlaneNum; i++) {

				   double keidoB = vec_ADS[i].Long;		//経度
				   double idoB = vec_ADS[i].Lat;		//緯度

				   double distABkm, dirABdeg;

				   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);

				   double alt_m = vec_ADS[i].Alt_feet * 0.305;  // FEET-->meter

				   Mat2 M_dirAB;

				   M_dirAB.set_axis_rot(-dirABdeg);

				   Vct2 Wa(0, 1);

				   // 航空機の座標や向きの計算用の回転行列　
				   // 　中心点からの角度、回転視野角度、航空機の向き
				   //
				   Vct2 Wb = distABkm * ((M_gR * M_dirAB) * Wa);

				   short X2 = gLx / 2 + FactH * gLx / Radius_km * Wb.x;
				   short Y2 = gLy / 2 - FactH * gLx / Radius_km * cos(ang1 * PI / 180.0) * Wb.y;

				   //2024-03-27
				   int Ti_sec = vec_ADS[i].Ti_sec;
 

				   String^ S1;
				   String^ S2;

				   if (CGPCommon::IsPlaneMark == 1) {

					   if (!vec_ADS[i].strFligtNumber.compare(0, 3, "   ")) {
						   S1= gcnew String(vec_ADS[i].strHex.c_str());
					   }
					   else {
						   S1 = gcnew String(vec_ADS[i].strFligtNumber.c_str());
					   }
				   }
				   else if (CGPCommon::IsPlaneMark == 2) {

					   S2 = gcnew String(alt_m.ToString("#####"));
				   
				   }
				   else if (CGPCommon::IsPlaneMark == 3) {
					  
					   if (!vec_ADS[i].strFligtNumber.compare(0, 3, "   ")) {
						   S1 = gcnew String(vec_ADS[i].strHex.c_str());
					   }
					   else {
						   S1 = gcnew String(vec_ADS[i].strFligtNumber.c_str());
					   }


					   S2 = gcnew String(alt_m.ToString("#####"));
				   }

				   double b_a = (vec_ADS[i].HeadDirection - dirABdeg);

				   short s;

				   CGPCommonDefinition::DispPos2D P2d;

				   if (ang1 >= 5.0) {

					   //斜めからの図

					   s = 5;
					   _Grph1->FillEllipse(brGray, X2 - s, Y2 - s + s, 2 * s, 1 * s);			//航空機の真下の地面点（海抜０m補正）

					   short iH;
					   if (CGPCommon::Height_exaggeration == 0) {
						   iH = sin(gDEPRS_DEG * D2R) * (FactH * gLx) * alt_m / (Radius_km * 1000.);
					   }
					   else {
						   iH = (FactH * gLx) * alt_m / (Radius_km * 1000.);
					   }
					   //241205 short iH = (FactH * gLx) * alt_m / (Radius_km * 1000.);

					   s = 3;
					   _Grph1->DrawEllipse(penYellow, X2 - s, Y2 - s - iH, 2 * s, 2 * s);	//航空機（高さ考慮）の位置

					   if (Ti_sec > 1) {
						   // 経過時間[秒] 経験から、電波が届かない場所近辺で、２秒以上になる。
						   _Grph1->DrawEllipse(penRed, X2 - s, Y2 - s - iH, 2 * s, 2 * s);	//航空機（高さ考慮）の位置
					   }

					   P2d.X = X2 - s;
					   P2d.Y = Y2 - s - iH;

					   _Grph1->DrawLine(penDimGray_Dot, X2, Y2, X2, Y2 - iH);					//航空機の高度を示す垂直線

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {
						   //航空機がマウスで指定されているとき
						   _Grph1->DrawString(S1, fntS, brRed, X2 + s + 1, Y2 - iH + s - 30);			//便名　
						   _Grph1->DrawString(S2, fntS, brRed, X2 + s + 1, Y2 - iH + s + 10 - 30);		//高度　
					   }
					   else {
						   _Grph1->DrawString(S1, fntS, brYellow, X2 + s + 1, Y2 - iH + s - 30);		//便名　
						   _Grph1->DrawString(S2, fntS, brYellow, X2 + s + 1, Y2 - iH + s + 10 - 30);	//高度
					   }

					   double degD = vec_ADS[i].HeadDirection + gROUND_DEG;

					   Vct2 Ps(X2, Y2 - iH);
					   Vct2 V(cos(-(90 - degD) * PI / 180.0), sin((90 - degD) * PI / 180.0));

					   V = SPEED_FCT * vec_ADS[i].Spd_mile * V;	//飛行機の矢印の大きさ

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {
						   _Grph1->DrawLine(penRed, (short)Ps.x, (short)Ps.y, (short)Ps.x + V.x, (short)Ps.y - V.y * cos(ang1 * PI / 180.0));
					   }
					   else {
						   _Grph1->DrawLine(penGlay, (short)Ps.x, (short)Ps.y, (short)Ps.x + V.x, (short)Ps.y - V.y * cos(ang1 * PI / 180.0));
					   }
				   }
				   else if (ang1 < 5) {

					   //平面図
					   // 垂直の足は省略します
					   //
					   s = 3;

					   _Grph1->DrawEllipse(penYellow, X2 - s, Y2 - s, 2 * s, 2 * s);  //航空機位置

					   if (Ti_sec > 1) {
						   // 経過時間[秒] 経験から、電波が届かない場所近辺で、２秒以上になる。
						   _Grph1->DrawEllipse(penRed, X2 - s, Y2 - s, 2 * s, 2 * s);  //航空機位置
					   }


					   P2d.X = X2 - s;
					   P2d.Y = Y2 - s;

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {
						   //航空機がマウスで指定されているとき
						   _Grph1->DrawString(S1, fntS, brRed, X2 + 1, Y2 + 1);		//便名　
						   _Grph1->DrawString(S2, fntS, brRed, X2 + 1, Y2 + 1 + 10);  //高度
					   }
					   else {
						   _Grph1->DrawString(S1, fntS, brYellow, X2 + 1, Y2 + 1);		//便名　
						   _Grph1->DrawString(S2, fntS, brYellow, X2 + 1, Y2 + 1 + 10);  //高度
					   }

					   double degD = vec_ADS[i].HeadDirection + gROUND_DEG;

					   Vct2 Ps(X2, Y2);
					   Vct2 V(cos(-(90 - degD) * PI / 180.0), sin((90 - degD) * PI / 180.0));

					   V = SPEED_FCT * vec_ADS[i].Spd_mile * V;	//飛行機の矢印の大きさ

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {
						   //航空機がマウスで指定されているとき
						   _Grph1->DrawLine(penRed, (short)Ps.x, (short)Ps.y, (short)Ps.x + V.x, (short)Ps.y - V.y);
					   }
					   else {
						   _Grph1->DrawLine(penGlay, (short)Ps.x, (short)Ps.y, (short)Ps.x + V.x, (short)Ps.y - V.y);
					   }
				   }

				   // 2次元場所の登録
				   CGPCommon::_mapDispPos[vec_ADS[i].strHex] = P2d;

			   }

			   /////////////////////////////////
			   // 過去の航空機の軌跡を削除する
			   /////////////////////////////////

			   if ( gCnt%100==0 ) {  // 100/4=約25秒毎
				  
				   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it;
				   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it2;

				   //MngFnc::WriteCsvLog("gCnt="+gCnt.ToString());

				   std::string strKeyFormer = "";
				   long int CounterFormer=-1;

				   std::set< std::string > setKeyVanish;   //重複なし

				   for (it = CGPCommon::_mltMapTrail.begin(); it != CGPCommon::_mltMapTrail.end(); it++) {
					   
					   std::string strKey=it->first;
					   long int Counter=(it->second).Counter;

					   (it->second).Lat;
					   (it->second).Long;
					   (it->second).Alt_m;


					   if (!std::strcmp(strKey.c_str(), strKeyFormer.c_str())) {
						   ; //nop
						   //   [A1] 12
						   //   [A1] 13
						   //   [A1] 14
						   //    ...
						   //   [A1] 96  <---  この境界を見つける
						   //   [A2] 15  <---
						   //   [A2] 16
						   //    ...

					   }
					   else{

						   if (strKeyFormer.size() > 0) {
							   if ((gCnt - CounterFormer) > 1000) {   //1000/4=250秒以上、音信が無い場合
								   setKeyVanish.insert(strKeyFormer);
							   }
						   }

					   }
					   strKeyFormer = strKey;
					   CounterFormer = Counter;

				   }

				   for (auto ite = setKeyVanish.begin(); ite != setKeyVanish.end(); ite++) {
					   
					   std::string strKey = ite->c_str();

					   std::string strFlightNumber = CGPCommon::_mapFlightCode[strKey.c_str()];
					   
					   String^ S1;

					   if (!strFlightNumber.compare(0, 3, "   ")) {
						   S1 = gcnew String(strKey.c_str());
					   }
					   else {
						   S1 = gcnew String(strFlightNumber.c_str());
					   }
					   //MngFnc::WriteCsvLog("disappear:" + S1);

					   {
						   //2024-03-06
						   //　順番 Flight,Alt,Lat,Long,Alt,Lat,Long
						   String^ Mes1 = S1 + ",";

						   int Cnt = CGPCommon::_mltMapTrail.count(strKey.c_str());

						   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it;

						   it = CGPCommon::_mltMapTrail.find(strKey.c_str());

						   for (int j = 0; j < Cnt; j++) {

							   if (j == 0) { 
								   double alt_m = (*it).second.Alt_m;
								   double idoB = (*it).second.Lat;
								   double keidoB = (*it).second.Long;

								   Mes1 = Mes1 + alt_m.ToString() + "," + idoB.ToString() + "," + keidoB.ToString()+",";
							   }
							   else if (j == Cnt - 1) {
								   double alt_m = (*it).second.Alt_m;
								   double idoB = (*it).second.Lat;
								   double keidoB = (*it).second.Long;

								   Mes1 = Mes1 + alt_m.ToString() + "," + idoB.ToString() + "," + keidoB.ToString();
							   }

							   it++;
						   }

						   MngFnc::WriteCsvLog(Mes1);

					   }

					   CGPCommon::_mltMapTrail.erase(strKey.c_str());
 
				   }

			   }
			

			   //////////////////////
			   // 文字情報　左上側
			   //////////////////////

			   DateTime now = DateTime::Now;
			   String^ Str_Now = now.ToString("yyyy-MM-dd HH:mm:ss");
			   _Grph1->DrawString("Date:" + Str_Now, fntM, brMagenta, 5, 5);

			   _Grph1->DrawString("Center:" + S_LocName, fntM, brMagenta, 5, 20);
			   _Grph1->DrawString("Plane:" + PlaneNum.ToString(), fntM, brMagenta, 5, 40);
			 
			   int cnt = CGPCommon::_mltMapTrail.size();
			   _Grph1->DrawString("TrailSize:" + cnt.ToString(), fntM, brMagenta, 5, 55);

			   _Grph1->DrawString("gCnt:" + gCnt.ToString(), fntM, brMagenta, 5, 70);

			   _Grph1->DrawString("QueueNum:" + gNumQueue.ToString(), fntM, brMagenta, 5, 85);


			   this->pictureBox1->Refresh();  //2023-09-11

			   return(0);
		   }

		   int sub_Clipping(
			   std::vector<DispPos2D > vecDP,						//(in) 閉曲線（例　伊豆大島）　ダブりなし（終点≠始点）
			   std::vector<std::vector<DispPos2D >>& vec_vec_DP2)	//(out)表示エリアの長方形でクリッピングされた、閉曲線（１個以上）
		   {

			   int numDP = vecDP.size();

			   //準備
			   std::vector<Vct2> vecRect5Points;
			   {
				   //   (修正後）
				   // 
				   //    エクセル座標      画面座標（左手系）
				   //    R2--------R3     R1-------R4
				   //     |         |     |         |          
				   //     |         |     |         |
				   //     |         |     |         | 
				   //    R1---------R4    R2-------R3

				   Vct2 R1(0, 0);
				   Vct2 R3(gLx - 1, gLy - 1);
				   Vct2 R4(gLx - 1, 0);
				   Vct2 R2(0, gLy - 1);

				   vecRect5Points.push_back(R1);
				   vecRect5Points.push_back(R2);
				   vecRect5Points.push_back(R3);
				   vecRect5Points.push_back(R4);
				   vecRect5Points.push_back(R1);  //視点に合わせる
			   }


			   // 閉曲線vecDPの点の中から、□P1～P4の外側にある点を一つ見つける
			   int nOUT = -1;

			   for (int i = 0; i < vecDP.size(); i++)
			   {
				   short X1 = vecDP[i].X;
				   short Y1 = vecDP[i].Y;

				   bool bP1in = (0 < X1 && X1 < (gLx - 1)) && (0 < Y1 && Y1 < (gLy - 1));

				   if (bP1in == false) {
					   //　外側にある点を発見した
					   nOUT = i;
					   goto NEXT1;
				   }
			   }

		   NEXT1:
			   if (nOUT == -1) {
				   return(-1);  //エラー？
			   }

			   std::vector<DispPos2D > vecDPa_;

			   int N = vecDP.size();

			   for (int i = 0; i < N; i++) {
				   int k = (nOUT + i) % N;
				   DispPos2D DP = vecDP[k];
				   vecDPa_.push_back(DP);
			   }

			   DispPos2D DP = vecDPa_[0];
			   vecDPa_.push_back(DP); // 終点を始点にした
			   // vecDPa_はN+1点

			   std::vector<DispPos2D > vecDPb_; //　vecDPa_に対して、交点を追加した点列
			   vecDPb_.push_back(vecDPa_[0]);


			   for (int i = 1; i <= N; i++) {

				   //  //交点を求める
				   Vct2 P1(vecDPa_[i - 1].X, vecDPa_[i - 1].Y);
				   Vct2 P2(vecDPa_[i].X, vecDPa_[i].Y);
				   Vct2 Pcrs;

				   std::vector<Vct2> vecCrossPoint;
				   sub_LineSeg_Rect_CrossPoint(P1, P2, vecRect5Points, vecCrossPoint);

				   int numCrossPoint = vecCrossPoint.size();

				   if (numCrossPoint == 1) {
					   DispPos2D DP1;
					   DP1.X = vecCrossPoint[0].x;
					   DP1.Y = vecCrossPoint[0].y;
					   vecDPb_.push_back(DP1);
				   }
				   else if (numCrossPoint == 2) {
					   DispPos2D DP1;
					   DP1.X = vecCrossPoint[0].x;
					   DP1.Y = vecCrossPoint[0].y;
					   vecDPb_.push_back(DP1);

					   DispPos2D DP2;
					   DP2.X = vecCrossPoint[1].x;
					   DP2.Y = vecCrossPoint[1].y;
					   vecDPb_.push_back(DP2);
				   }
				   vecDPb_.push_back(vecDPa_[i]);

			   }

			   int sN = vecDPb_.size();

			   if (sN % 2 == 1) {
				   if (bIsFirstError == true) {
					   // まれに、ここに来る。無視して、うまく行く場合もあるので、対策保留。   
					   MngFnc::WriteCsvLog("交点が奇数個");
					   bIsFirstError = false;
				   }

				   //?? return(-1);
			   }
			   //MngFnc::WriteCsvLog("vecDPb_.size=" + vecDPb_.size().ToString());

			   if (1 == 0) {
				   if (bIsFirstPrint == true) {
					   MngFnc::WriteCsvLog(" ===================");
					   for (int i = 0; i < vecDPb_.size(); i++) {
						   MngFnc::WriteCsvLog("i=" + i.ToString() + "  ," + vecDPb_[i].X.ToString() + "," + vecDPb_[i].Y.ToString() + ","); 
					   }
					   MngFnc::WriteCsvLog(" ===================");
				   }
			   }

			   std::vector<LineSegment> vecLineSgmt;

			   for (int i = 0 + 1; i < vecDPb_.size(); i++) {

				   DispPos2D P1 = vecDPb_[i - 1];
				   DispPos2D P2 = vecDPb_[i];

				   LineSegment ls;

				   ls.Ps = P1;
				   ls.Pe = P2;

				   double xc = (P1.X + P2.X) / 2.0;
				   double yc = (P1.Y + P2.Y) / 2.0;

				   bool bX = (0 < xc && xc < (gLx - 1));
				   bool bY = (0 < yc && yc < (gLy - 1));

				   if ((bX == true) && (bY == true)) {
					   ls.bIsInROI = true;
				   }
				   else {
					   ls.bIsInROI = false;
				   }
				   vecLineSgmt.push_back(ls);

			   }

			   std::vector <ContPointSeq> vecCurveSgmt;
			   //struct ContPointSeq {
				  // std::vector<DispPos2D> vecDispPos2D;
			   //};

			   std::vector<DispPos2D> _vecDispPos2D;

			   int numLineSeg = vecLineSgmt.size();

			   for (int i = 0; i < numLineSeg; i++) {

				   if (vecLineSgmt[i].bIsInROI == true) {

					   DispPos2D DP = vecLineSgmt[i].Ps;
					   _vecDispPos2D.push_back(DP);

				   }

				   if (i < numLineSeg - 1) {

					   if (vecLineSgmt[i + 1].bIsInROI == false) {

						   if (vecLineSgmt[i].bIsInROI == true) {
							   DispPos2D DP = vecLineSgmt[i].Pe;
							   _vecDispPos2D.push_back(DP);

							   ContPointSeq cs;
							   cs.vecDispPos2D = _vecDispPos2D;
							   _vecDispPos2D.clear();

							   vecCurveSgmt.push_back(cs);
						   }
					   }
				   }

				   if (i == (numLineSeg - 1)) {
					   DispPos2D DP = vecLineSgmt[i].Pe;
					   _vecDispPos2D.push_back(DP);

					   if (_vecDispPos2D.size() >= 2) {
						   ContPointSeq cs;
						   cs.vecDispPos2D = _vecDispPos2D;
						   vecCurveSgmt.push_back(cs);
					   }
					   _vecDispPos2D.clear();
				   }


			   }

			   int numCVS = vecCurveSgmt.size();

			   if (numCVS == 0) {
				   return(-1);
			   }

			   // RECT境界線分の取得

			   std::vector <ContPointSeq> vecRectLineSgmt;

			   int er1 = sub_Rect_Line_Segment(vecCurveSgmt, vecRect5Points, vecRectLineSgmt);


			   //
			   // vecCurveSgmt, vecRectLineSgmtをマージする
			   //
			   int numRLS = vecRectLineSgmt.size();


			   if (numRLS != numCVS * 2) {
				   MngFnc::WriteCsvLog("NG" + " numCVS=" + numCVS.ToString() + "  numRLS=" + numRLS.ToString());
			   }

			   std::vector<int > CVS_USED(numCVS);
			   std::vector<int > CVS_CONNECT(numCVS);

			   std::vector<int > RLS_CONNECT(numRLS);

			   for (int i = 0; i < numCVS; i++) {
				   CVS_USED[i] = -1;
				   CVS_CONNECT[i] = -1;
			   }

			   for (int i = 0; i < numRLS; i++) {
				   RLS_CONNECT[i] = -1;
			   }


			   for (int i = 0; i < numCVS; i++) {

				   int num = vecCurveSgmt[i].vecDispPos2D.size();

				   DispPos2D PCs = vecCurveSgmt[i].vecDispPos2D[0];
				   DispPos2D PCe = vecCurveSgmt[i].vecDispPos2D[num - 1];

				   if ((PCs.X == PCe.X) && (PCs.Y == PCe.Y)) {
					   ; //nop
				   }
				   else {

					   for (int j = 0; j < numRLS; j++) {

						   int numRLs = vecRectLineSgmt[j].vecDispPos2D.size();

						   if (numRLs > 0) {

							   DispPos2D Ps = vecRectLineSgmt[j].vecDispPos2D[0];
							   DispPos2D Pe = vecRectLineSgmt[j].vecDispPos2D[numRLs - 1];
							   
							   if ((Ps.X == Pe.Y) && (Ps.Y == Pe.X)) {
								   ;//nop
							   }
							   else {
								   if (IsSamePoint(PCe, Ps) == 1) {
									   // 一致で、連結している
									   CVS_CONNECT[i] = j;
								   }
							   }
						   }
					   }
				   }
			   }


			   for (int i = 0; i < numRLS; i++) {

				   //この時点で、使用しないvecRectLineSgmtは、決まっているので除外できる
				   for (int j = 0; j < numCVS; j++) {
					   for (int k = 0; k < numCVS; k++) {
						   if (CVS_CONNECT[k] == i) {
							   goto NEXT5;
						   }
					   }
					   //ここまで来たら、未使用
					   goto NEXT6;
				   }

			   NEXT5:

				   int numA = vecRectLineSgmt[i].vecDispPos2D.size();

				   DispPos2D PCs = vecRectLineSgmt[i].vecDispPos2D[0];
				   DispPos2D PCe = vecRectLineSgmt[i].vecDispPos2D[numA - 1];

				   if ((PCs.X == PCe.X) && (PCs.Y == PCe.Y)) {
					   ; //nop
				   }
				   else {

					   for (int j = 0; j < numCVS; j++) {

						   int numB = vecCurveSgmt[j].vecDispPos2D.size();

						   DispPos2D Ps = vecCurveSgmt[j].vecDispPos2D[0];
						   DispPos2D Pe = vecCurveSgmt[j].vecDispPos2D[numB - 1];

						   if ((Ps.X == Pe.X) && (Ps.Y == Pe.Y)) {
							   ;//nop
						   }
						   else {
							   if (IsSamePoint(PCe, Ps) == 1) {
								   // 一致で、連結している  
								   RLS_CONNECT[i] = j;
							   }
						   }

					   }
				   }

			   NEXT6:
				   ;
			   }


			   // CVS_CONNECT,RLS_CONNECT　が埋まった

			   int ip = 0;

			   std::vector<DispPos2D> vec_DPS;


		   L_1:
			   if (CVS_USED[ip] == -1) {

				   int next_RLS = CVS_CONNECT[ip];

				   if (next_RLS < 0) {
					   goto NEXT99;
				   }

				   int next_CVS = RLS_CONNECT[next_RLS];

				   for (int k = 0; k < vecCurveSgmt[ip].vecDispPos2D.size(); k++) {
					   DispPos2D dps = vecCurveSgmt[ip].vecDispPos2D[k];
					   vec_DPS.push_back(dps);
				   }

				   for (int k = 0; k < vecRectLineSgmt[next_RLS].vecDispPos2D.size(); k++) {
					   DispPos2D dps = vecRectLineSgmt[next_RLS].vecDispPos2D[k];
					   vec_DPS.push_back(dps);  //とりあえず、ダブりを許す
				   }

				   CVS_USED[ip] = 1;

				   ip = next_CVS;

				   if (ip < 0) {
					   goto NEXT99;  //2023-12-27 ??
				   }

				   goto L_1;
			   }
			   else if (CVS_USED[ip] == 1) {
				   // 1ラインの登録
				   vec_vec_DP2.push_back(vec_DPS);
				   vec_DPS.clear();

				   for (int k = 0; k < numCVS; k++) {
					   if (CVS_USED[k] == -1) {
						   ip = k;
						   goto L_1;
					   }
				   }

			   }

		   NEXT99:

			   if (1 == 0) {
				   if (bIsFirstPrint == true) {

					   MngFnc::WriteCsvLog("vecDPb_.size=" + vecDPb_.size().ToString());

					   for (int i = 0; i < vecCurveSgmt.size(); i++) {
						   int num = vecCurveSgmt[i].vecDispPos2D.size();

						   for (int j = 0; j < num; j++) {
							   int x = vecCurveSgmt[i].vecDispPos2D[j].X;
							   int y = vecCurveSgmt[i].vecDispPos2D[j].Y;

							   MngFnc::WriteCsvLog("vecCurveSgmt[" + i.ToString() + "].vecDispPos2D[" + j.ToString() + "].X & Y=," + x.ToString() + "," + y.ToString());

						   }
					   }

					   for (int i = 0; i < vecRectLineSgmt.size(); i++) {
						   int num = vecRectLineSgmt[i].vecDispPos2D.size();

						   for (int j = 0; j < num; j++) {
							   int x = vecRectLineSgmt[i].vecDispPos2D[j].X;
							   int y = vecRectLineSgmt[i].vecDispPos2D[j].Y;

							   MngFnc::WriteCsvLog("vecRectLineSgmt[" + i.ToString() + "].vecDispPos2D[" + j.ToString() + "].X & Y=," + x.ToString() + "," + y.ToString());

						   }
					   }


					   for (int i = 0; i < numCVS; i++) {
						   MngFnc::WriteCsvLog("CVS_CONNECT[" + i.ToString() + "]=" + CVS_CONNECT[i].ToString());
					   }

					   for (int i = 0; i < numCVS; i++) {
						   MngFnc::WriteCsvLog("CVS_USED[" + i.ToString() + "]=" + CVS_USED[i].ToString());
					   }

					   for (int i = 0; i < numRLS; i++) {
						   MngFnc::WriteCsvLog("RLS_CONNECT[" + i.ToString() + "]=" + RLS_CONNECT[i].ToString());
					   }

					   int num1 = vec_vec_DP2.size();

					   for (int i = 0; i < num1; i++) {

						   int num2 = vec_vec_DP2[i].size();

						   for (int j = 0; j < num2; j++) {
							   int x = vec_vec_DP2[i][j].X;
							   int y = vec_vec_DP2[i][j].Y;

							   MngFnc::WriteCsvLog("vec_vec_DP2[" + i.ToString() + "].vecDispPos2D[" + j.ToString() + "].X & Y=," + x.ToString() + "," + y.ToString());
						   }
					   }


					   bIsFirstPrint = false;
				   }
			   }

			   int num_Seg = vec_vec_DP2.size();

			   if (num_Seg == 0) {
				   return(-2);
			   }

			   return(0);


		   }

		   int IsSamePoint(DispPos2D P1, DispPos2D P2) {

			   double dist = sqrt((P1.X - P2.X) * (P1.X - P2.X) + (P1.Y - P2.Y) * (P1.Y - P2.Y));

			   if (dist < 1.0) {
			   ///NG if (dist < 1.5) {  
				   return(1);  //一致

			   }
			   else {
				   return(0);
			   }
		   }


		   int sub_LineSeg_Rect_CrossPoint(Vct2 P1,Vct2 P2, std::vector<Vct2> vec5Points, std::vector<Vct2>& vecCrossPoint) {
			   
			   //     R2--------R3
			   //     |         |               
			   //     |   ●----|-------○
			   //     |   IN    |      OUT
			   //     R1--------R4
			   // 
			   //  （注意）　IN--IN   OUT---OUT もありえます。
			   	  
			   int nP = vec5Points.size();  // 長方形のときは、5です。始点＝終点　
			   
			   if (nP != 5) {
				   return(-1);
			   }

			   vecCrossPoint.clear();
 
			   Mat2 M;

			   for (int i = 0; i < nP-1; i++) {

				   Vct2 Q1 = vec5Points[i];
				   Vct2 Q2 = vec5Points[i + 1];
				   
				   M.m_11 = (P2 - P1 | Q2 - Q1);
				   M.m_12 = -(Q2 - Q1 | Q2 - Q1);
				   M.m_21 = (P2 - P1 | P2 - P1);
				   M.m_22 = -(Q2 - Q1 | P2 - P1);

				   if (fabs(M.det()) < Vct2Const::ZERO_TOLERANCE) {		//行列式が０
					   continue;	//次のループへ
				   }

				   Vct2 Va((Q1 - P1 | (Q2 - Q1)), (Q1 - P1 | P2 - P1));

				   Vct2 V_s_t = M.Inverse() * Va;
			

				   //交点判定
				   double s = V_s_t.x;
				   double t = V_s_t.y;

				   bool b_is_s_0_1 = (0 < s) && (s < 1);
				   bool b_is_t_0_1 = (0 < t) && (t < 1);

				   if (b_is_s_0_1 == true && b_is_t_0_1 == true) {
					   
					   //交点あり
					   //Vct2 Vc = P1 + s * (P2 - P1);  // =Q1+s*(Q2-Q1)のはず
					   Vct2 Vc = Q1 + t * (Q2 - Q1);   // でないと誤差がのる。

					   vecCrossPoint.push_back(Vc);
				   }
			   }

			   int numCrossPoint = vecCrossPoint.size();

			   if (numCrossPoint == 2) {
				   //　P1から近い順に点を入れ替えます
				   double len1 = sqrt((P1.x - vecCrossPoint[0].x) * (P1.x - vecCrossPoint[0].x) + (P1.y - vecCrossPoint[0].y) * (P1.y - vecCrossPoint[0].y));
				   double len2 = sqrt((P1.x - vecCrossPoint[1].x) * (P1.x - vecCrossPoint[1].x) + (P1.y - vecCrossPoint[1].y) * (P1.y - vecCrossPoint[1].y));
			   
				   if (len1 > len2) {
					   Vct2 Vw = vecCrossPoint[0];
					   vecCrossPoint[0] = vecCrossPoint[1];
					   vecCrossPoint[1] = Vw;
				   }
			   }

			   return(0);

		   }

		   int sub_Rect_Line_Segment(std::vector <ContPointSeq> vecCurveSgmt, std::vector<Vct2> vec5Points, std::vector <ContPointSeq>& vecRectLineSgmt) {
			//
			//
			//   (修正後）
			// 
			//    エクセル座標      画面座標（左手系）
			//    R2--------R3     R1-------R4
			//     |         |     |         |          
			//     |         |     |         |
			//     |         |     |         | 
			//    R1---------R4    R2--------R3
			// 
			//  （注意）　IN--IN   OUT---OUT もありえます。
			//
			   int nP = vec5Points.size();  // 長方形。　5です。始点＝終点　

			   if (nP != 5) {
				   return(-1);
			   }

			   DispPos2D R1, R2, R3, R4, R5;

			   R1.X = vec5Points[0].x;
			   R2.X = vec5Points[1].x;
			   R3.X = vec5Points[2].x;
			   R4.X = vec5Points[3].x;
			   R5.X = vec5Points[4].x;

			   R1.Y = vec5Points[0].y;
			   R2.Y = vec5Points[1].y;
			   R3.Y = vec5Points[2].y;
			   R4.Y = vec5Points[3].y;
			   R5.Y = vec5Points[4].y;

			   int numCS = vecCurveSgmt.size();

			   std::vector<Vct2 > vecPnts;


			   for (int i = 0; i < numCS; i++) {

				   int num = vecCurveSgmt[i].vecDispPos2D.size();

				   DispPos2D DPs = vecCurveSgmt[i].vecDispPos2D[0];
				   DispPos2D DPe = vecCurveSgmt[i].vecDispPos2D[num - 1];

				   Vct2 Vs(DPs.X, DPs.Y);
				   Vct2 Ve(DPe.X, DPe.Y);

				   vecPnts.push_back(Vs);
				   vecPnts.push_back(Ve);

			   }

			   //vecPntsは、RECT境界上の点

			   std::multimap<double, Vct2> mltmpVct2;

			   int numP1 = vecPnts.size();

			   Vct2 Porg;

			   // vec_Pntsが一直線上に並ぶ時があるので、対策
			   for (int i = 0; i < numP1; i++) {
				   Porg = Porg + vecPnts[i];
			   }
			   for (int i = 0; i < 4; i++) {
				   Porg = Porg + vec5Points[i];
			   }
			   Porg = (1.0 / (numP1 + 4)) * Porg;



			   for (int i = 0; i < numP1; i++) {

				   Vct2 Pnt = vecPnts[i];

				   Vct2 v0(0, -1);
				   //Vct2 v0(1, 0);
				   Vct2 v1 = Pnt - Porg;
				   double cosA = (v0 | v1) / (v0.length() * v1.length());
				   double D2R = PI / 180.0;
				   double degA = (acos(cosA)) / D2R;  // 0---180
 
				   // N方向を0°で反時計回りに0～360°とするため。
				   if (v1.x >= 0) {
					   degA = -degA;
				   }
				   else {
					   degA = +degA;
				   }

				   mltmpVct2.insert(std::pair<double, Vct2>(degA, Pnt));

			   }

			   std::multimap<double, Vct2>::iterator p;

			   std::vector<Vct2 > vecPnts_sorted;
		 
			   // ソート
			   for (p = mltmpVct2.begin(); p != mltmpVct2.end(); p++) {
				   //ソートされています。
				   vecPnts_sorted.push_back(p->second);
			   }
 
			   int numPs = vecPnts_sorted.size();


			   /*if ( bIsFirstPrint==true){

				   for (int i = 0; i < numPs; i++) {

					   int iX = (int)vecPnts_sorted[i].x;
					   int iY = (int)vecPnts_sorted[i].y;
					   MngFnc::WriteCsvLog("vecPnts_sorted[" + i.ToString() + "].X & Y=," + iX.ToString() + "," + iY.ToString());   
				   }
			   }*/

			   // 終点＝始点にする
			   Vct2 Vw = vecPnts_sorted[0];
			   vecPnts_sorted.push_back(Vw);

			   int numP = vecPnts_sorted.size();

			   double X0 = 0;
			   double XL = (double)gLx - 1;
			   double Y0 = 0;
			   double YL = (double)gLy - 1;
			  

			   for (int i = 0; i < (numP - 1); i++) { 

				   ContPointSeq cps;

				   DispPos2D P1;
				   P1.X = vecPnts_sorted[i].x;
				   P1.Y = vecPnts_sorted[i].y;

				   DispPos2D P2;
				   P2.X = vecPnts_sorted[i + 1].x;
				   P2.Y = vecPnts_sorted[i + 1].y;

				   if (P1.X <= X0) {  
					   if (P2.X <= X0) {
						   if (P1.Y > P2.Y) {
							   // ①
							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(R2);
							   cps.vecDispPos2D.push_back(R3);
							   cps.vecDispPos2D.push_back(R4);
							   cps.vecDispPos2D.push_back(R1);
							   cps.vecDispPos2D.push_back(P2);
						   }
						   else {
							   // ②
							   cps.vecDispPos2D.push_back(P1);  //ここ注意
							   cps.vecDispPos2D.push_back(P2);
						   }
					   }
					   else if (P2.Y <= Y0) {  //
						   // ③
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R2);
						   cps.vecDispPos2D.push_back(R3);
						   cps.vecDispPos2D.push_back(R4);
						   cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.X >=XL) {
						   // ④
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R2);
						   cps.vecDispPos2D.push_back(R3);
						   cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.Y >= YL) {
						   // ⑤
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R2);
						   cps.vecDispPos2D.push_back(P2);
					   }
				   }
				   else if (P1.Y <= Y0) {

					   if (P2.Y <= Y0) {
						 
						   if (P1.X < P2.X) {
							   // ⑥
							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(R1);
							   cps.vecDispPos2D.push_back(R2);
							   cps.vecDispPos2D.push_back(R3);
							   cps.vecDispPos2D.push_back(R4);
							   cps.vecDispPos2D.push_back(P2);
						   }
						   else {
							   //⑦
							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(P2);
						   }
					   }
					   else if (P2.X >= XL) {
						   // ⑧
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R1);
						   cps.vecDispPos2D.push_back(R2);
						   cps.vecDispPos2D.push_back(R3);
						   cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.Y >=YL) {
						   // ⑨
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R1);
						   cps.vecDispPos2D.push_back(R2);
						   cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.X <=X0) {
						   // ⑩
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R1);
						   cps.vecDispPos2D.push_back(P2);
					   }
				   }
				   else if (P1.X >= XL) { 
					   if (P2.X >= XL) { 
						   if (P1.Y < P2.Y) { 
								// ⑪

							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(R4);
							   cps.vecDispPos2D.push_back(R1);
							   cps.vecDispPos2D.push_back(R2);
							   cps.vecDispPos2D.push_back(R3);
							   cps.vecDispPos2D.push_back(P2);
						   }
						   else {
								// ⑫
							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(P2);

						   }
					   }
					   else if (P2.Y >= YL) {
						   // ⑬
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R4);
						   cps.vecDispPos2D.push_back(R1);
						   cps.vecDispPos2D.push_back(R2);
						   cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.X <= X0) {
						   // ⑭
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R4);
						   cps.vecDispPos2D.push_back(R1);
						   cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.Y <= Y0) {
						   // ⑮
						   cps.vecDispPos2D.push_back(P1);
						   cps.vecDispPos2D.push_back(R4);
						   cps.vecDispPos2D.push_back(P2);
					   }
				   }
				   else if (P1.Y >=YL) {
						if (P2.Y >= YL) {
						   if (P1.X > P2.X) {
								//　⑯

							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(R3);
							   cps.vecDispPos2D.push_back(R4);
							   cps.vecDispPos2D.push_back(R1);
							   cps.vecDispPos2D.push_back(R2);
							   cps.vecDispPos2D.push_back(P2);
						   }
						   else {
							   // ⑰
							   cps.vecDispPos2D.push_back(P1);
							   cps.vecDispPos2D.push_back(P2);

						   }
					   }
						else if (P2.X <= X0) { 
						   // ⑱
							cps.vecDispPos2D.push_back(P1);
							cps.vecDispPos2D.push_back(R3);
							cps.vecDispPos2D.push_back(R4);
							cps.vecDispPos2D.push_back(R1);
							cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.Y <= Y0) { 
						   // ⑲
							cps.vecDispPos2D.push_back(P1);
							cps.vecDispPos2D.push_back(R3);
							cps.vecDispPos2D.push_back(R4);
							cps.vecDispPos2D.push_back(P2);
					   }
					   else if (P2.X >=XL) {
						   // ⑳
							cps.vecDispPos2D.push_back(P1);
							cps.vecDispPos2D.push_back(R3);
							cps.vecDispPos2D.push_back(P2);

					   }
				   }

				   vecRectLineSgmt.push_back(cps);

			   }

			   int numRLS = vecRectLineSgmt.size();

			   return(0);

		   }


		   // 垂直方向　（360度の視界　円筒座標）
		   int PlotPlanes_Vertical(
			   std::vector<strct_ADS >  vec_ADS
		   )
		   {
			 
			   gPlaneNum = vec_ADS.size();

			   Vct2 O1, p1, p2, p3, p4, p5, p6;

			   Vct2 Ex(1, 0);
			   Vct2 Ey(0, 1);

			   double idoA;
			   double keidoA;
			   String^ S_LocName;


			   int iLM = max(0,this->listBoxKijyunLoc->SelectedIndex);

			   int DispKind_ex = CGPCommon::nDispKind;

			   int NumLandMarks = CGPCommon::_vec_LandMarks.size();

			   idoA = CGPCommon::_vec_LandMarks[iLM].ido;
			   keidoA = CGPCommon::_vec_LandMarks[iLM].keido;
			   S_LocName = gcnew String(CGPCommon::_vec_LandMarks[iLM].strLongName.c_str());


			   if (CGPCommon::strHex_pointing_Now.size() == 0) {

				   // 飛行機がマウス選択されていないとき
				   ; //nop

			   }
			   else if (CGPCommon::strHex_pointing_Now.size() > 0) {

				   // 飛行機がマウス選択されているとき
				   // その飛行機を左右の中心にします
				   int PlaneNum;

				   if (DispKind_ex / 2 == 0) {
					   //飛行機表示をしないとき
					   PlaneNum = 0;
				   }
				   else {
					   PlaneNum = vec_ADS.size();
				   }

				   for (int i = 0; i < PlaneNum; i++) {

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {

						   strct_ADS ADS = vec_ADS[i];

						   if (ADS.Lat == 0 && ADS.Long == 0) {
							   return(1); //変だ
						   }

						   double distABkm, dirABdeg;

						   double keidoB = vec_ADS[i].Long;		//経度
						   double idoB = vec_ADS[i].Lat;		//緯度

						   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);

						   gROUND_DEG = -dirABdeg;

						   bIsGenerateMap = true;

						   goto NEXT_1;

					   }
				   }

				   CGPCommon::TimerInterval = CGPCommon::TimerInterval + 1;

				   if (CGPCommon::TimerInterval > 4 * 10) {   // 10秒すぎたら

					   CGPCommon::strHex_pointing_Now.clear();


					   for (int i = 0; i < PlaneNum; i++) {
						   if (vec_ADS[i].strFligtNumber.compare(0, 1, " ")) {
							   // " "でない＝フライトNoが存在する
							   CGPCommon::strHex_pointing_Now = vec_ADS[i].strHex;
							   goto NEXT100;
						   }

					   }

				   NEXT100:
					   ;
				   }

				   // 見つからないときは、抜ける
				   return(1);

			   }

		   NEXT_1:
			

			   int MaxDegRITSUMEN = CGPCommon::Elevation_angle_kind * 30;

			   if (0 == 0) {
				   _Grph1->Clear(System::Drawing::Color::FromArgb(32,32,96));  
			   }
			   else {
				   _Grph1->Clear(System::Drawing::Color::DarkSlateBlue);
			   } 


			   //////////////////////////////////////
			   // 航空機位置をマルチマップに登録
			   //////////////////////////////////////
			   for (int i = 0; i < vec_ADS.size(); i++) {

				   CGPCommonDefinition::strct_Trail trail;
				   trail.Counter = gCnt;
				   trail.Alt_m = vec_ADS[i].Alt_feet * 0.305;
				   trail.Lat = vec_ADS[i].Lat;			//緯度
				   trail.Long = vec_ADS[i].Long;		//経度 
				   trail.Ti_sec = vec_ADS[i].Ti_sec;	//

				   CGPCommon::_mltMapTrail.insert(std::pair<std::string, CGPCommonDefinition::strct_Trail>(vec_ADS[i].strHex, trail));

				   CGPCommon::_mapFlightCode[vec_ADS[i].strHex] = vec_ADS[i].strFligtNumber;
			   }

			   int PlaneNum;

			   if (DispKind_ex / 2 == 0) {
				   //飛行機表示をしないとき
				   PlaneNum = 0;
			   }
			   else {
				   PlaneNum = vec_ADS.size();
			   }

			   short OFSY = 120;
			   //short OFSY = 100;

			   double FactH = 0.4;




			   //////////////////////////////////////
			   //航空機の軌跡 in PlotPlanes_Vertical
			   ////////////////////////////////////// 

			   for (int i = 0; i < PlaneNum; i++) {

				   std::vector<double> vec1;
				   std::vector<double> vec2;

				   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it;


				   std::vector<Vct3 >vecAIK,vecAIK_w;  

				   if ((CGPCommon::IsTrail == false)) {

					   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) {
						   // （航空機の軌跡を描くモードではなくても）マウスクリックされていたら、その１機だけの軌跡を描きます。
						   ;
					   }
					   else {
						   //航空機の軌跡を描かないモードのときは、普通、ここを通ります。
						   goto JUMP1;
					   }

				   }
				   else {
					   //航空機の軌跡を描くモードのときは、ここを通ります。
					   ;
				   }


				   short iX, iY, iX_former, iY_former;

				   double alt_m_former, idoB_former, keidoB_former;  //2023-08-12 


				   // 離陸 or 着陸  最初と最後の高度差で判断
				   bool bIsLanding;

				   double alt1 = 0;
				   double alt2 = 0;

				   // １飛行機の追跡線（飛行機雲）の線分数
				   int Cnt = CGPCommon::_mltMapTrail.count(vec_ADS[i].strHex.c_str());

				   it = CGPCommon::_mltMapTrail.find(vec_ADS[i].strHex.c_str());
  
				   for (int j = 0; j < Cnt; j++) {

					   double alt_m = (*it).second.Alt_m;
					   double idoB = (*it).second.Lat;
					   double keidoB = (*it).second.Long;

					   Vct3 AIK;
					   AIK.x = alt_m;
					   AIK.y = idoB;
					   AIK.z = keidoB;
					   vecAIK.push_back(AIK);

					   it++;

				   }


				   if (CGPCommon::trailMovingAverage_N > 0) {
					   
					   // 移動平均

					   int N = CGPCommon::trailMovingAverage_N;  

					   vecAIK_w = vecAIK;


					   for (int j = 0 + N; j < Cnt - N; j++) {

						   Vct3 AIK;

						   for (int k = -N; k <= N; k++) {

							   AIK = AIK + vecAIK_w[j + k];
						   }

						   AIK = AIK / (N * 2 + 1);

						   vecAIK[j] = AIK;
					   }
	 
				   }

				   //////////////////////////////////////////
				   //航空機が、着陸態勢か否かを判断する
				   //////////////////////////////////////////
				   for (int j = 0; j < Cnt / 5; j++) {

					   double alt_m = vecAIK[j].x;

					   vec1.push_back(alt_m);

				   }

				   for (int j = 4 * (Cnt / 5); j < Cnt; j++) {

					   double alt_m = vecAIK[j].x;

					   vec2.push_back(alt_m);

				   }


				   // まれに発生するスパイクノイズを避けるため処理
				   std::sort(vec1.begin(), vec1.end());
				   std::sort(vec2.begin(), vec2.end());

				   if (vec1.size() > 5 && vec2.size() > 5) {
					   alt1 = vec1[vec1.size() / 2];
					   alt2 = vec2[vec2.size() / 2];
				   }
				   else if (vec1.size() > 0 && vec2.size() > 0) {
					   alt1 = vec1[0];
					   alt2 = vec2[0];
				   }

				   if (alt1 > alt2) {
					   //着陸
					   bIsLanding = true;
				   }
				   else {
					   //離陸
					   bIsLanding = false;
				   }

				  
 
				   for (int j = 0; j < Cnt; j++) { 

					   double alt_m = vecAIK[j].x;
					   double idoB = vecAIK[j].y;
					   double keidoB = vecAIK[j].z;	   

					   double distABkm, dirABdeg;

					   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);

					   // 2025-10-27 立面時、表示半径を小さくすると、左右の角度幅も小さくなるように改造
					   double deg = dirABdeg;
					   double BAI = max(2 / log10(gRadius_km), 1);
					   short LX_ = BAI * gLx;

					   iX = short(LX_ * (360 * 2 + deg + gROUND_DEG - 360 + 180 / BAI) / 360) % LX_;

					   if (CGPCommon::Elevation_angle_kind == 0) {
						   //高さ
						   iY = -OFSY + gLy - alt_m / 12000. * (gLy - OFSY);
					   }
					   else {
						   //角度
						   double tanA = alt_m / (distABkm * 1000.0);
						   double degA = 180 / PI * atan(tanA);

						   iY = -OFSY + gLy - degA / MaxDegRITSUMEN * (gLy - OFSY);
					   }

					   if (j > 0) {

						   if ((idoB == idoB_former) && (keidoB == keidoB_former)) {
							   //?? goto NEXT1;
							   goto NEXT2;

						   }

						   if (abs(iX - iX_former) > gLx * 0.5) {
							   //０度～３６０度またぎなので、不要とします。（画面が見にくくなる）
							   ;
						   }
						   else {

							   // 軌跡の尾の長さ
							   if (j < (Cnt - CGPCommon::TailNo)) {
								   goto NEXT1; //nop
							   }

							   // まれに、航路が不連続になるときがあるので、排除します
							   bool bIsOK = (sqrt((iX - iX_former) * (iX - iX_former) + (iY - iY_former) * (iY - iY_former)) < D666);

							   if (bIsOK == true) {
								    
								   short penThick = CGPCommon::trailThickness;

								   // 立面時 
								   if ((idoB==idoB_former) && (keidoB== keidoB_former)) {
									    
									   idoB = idoB_former;
									   keidoB = keidoB_former;
									   alt_m = alt_m_former;
								   }
								   else {
									   sub_Grph1_DrawTrail(bIsLanding, penThick, iX, iY, iX_former, iY_former);
								   }
 
							   }

						   }
					   }

				   NEXT1:
					   ;

					   iX_former = iX;
					   iY_former = iY;

					   alt_m_former = alt_m;
					   idoB_former = idoB;
					   keidoB_former = keidoB;

				   NEXT2:
					   ;

					   //it++;

				   }
			   JUMP1:
				   ;

			   }


			   /////////////////////////
			   //地図の縦、横、補助線
			   /////////////////////////
			   short L;
			   short iY;

			   if (CGPCommon::Elevation_angle_kind == 0) {

				   // 高さ表示
				   iY = -OFSY + gLy - 0. / 12000. * (gLy - OFSY);
				   _Grph1->DrawLine(penRed, 0, gLy - OFSY, gLx - 1, gLy - OFSY);  //高度0
				   L = 0;
				   _Grph1->DrawString(L.ToString(), fntM, brYellow, 5, iY - 15);


				   iY = -OFSY + gLy - 5000. / 12000. * (gLy - OFSY);
				   _Grph1->DrawLine(pen_PV_Red, 0, iY, gLx - 1, iY);  //高度5000m
				   L = 5000;
				   _Grph1->DrawString(L.ToString(), fntM, brYellow, 5, iY - 15);


				   iY = -OFSY + gLy - 10000.0 / 12000. * (gLy - OFSY);
				   _Grph1->DrawLine(pen_PV_Red, 0, iY, gLx - 1, iY);  //高度10000m
				   L = 10000;
				   _Grph1->DrawString(L.ToString(), fntM, brYellow, 5, iY - 15);
			   }
			   else {

				   // 角度表示 

				   // 0°
				   iY = -OFSY + gLy - 0.0 / MaxDegRITSUMEN * (gLy - OFSY);
				   _Grph1->DrawLine(penRed, 0, gLy - OFSY, gLx - 1, gLy - OFSY);  //0
				   L = 0;
				   _Grph1->DrawString(L.ToString(), fntM, brYellow, 5, iY - 15);



				   //5°～

				   for (int i = 0; i < MaxDegRITSUMEN; i = i + 5) {

					   iY = -OFSY + gLy - double(i) / MaxDegRITSUMEN * (gLy - OFSY);
					   _Grph1->DrawLine(penDimGray_Dot, 0, iY, gLx - 1, iY);  //15°
					   L = i;

					   if (iY > 100) {  //QueueNumと重ならないようにする
						   _Grph1->DrawString(L.ToString(), fntM, brYellow, 5, iY - 15);
					   }
				   }


				   ////30°
				   //iY = -OFSY + gLy - 30.0 / 30.0 * (gLy - OFSY);
				   //_Grph1->DrawLine(pen_PV_Red, 0, iY, gLx - 1, iY);  //30°
				   //L = 30;
				   //_Grph1->DrawString(L.ToString(), fntM, brYellow, 5, iY - 15);
			   }


			   for (int i = 0; i < 360; i = i + 10) {

				   double deg = i;
				   double BAI = max(2 / log10(gRadius_km), 1);
				   short LX_ = BAI * gLx;

				   //short iX = short(LX_ * (M180 + 360 * 2 + deg + gROUND_DEG) / 360) % LX_;
				   short iX = short(LX_ * (360 * 2 + deg + gROUND_DEG - 360 + 180 / BAI) / 360) % LX_;

				   short dy;

				   if (i % 90 == 0) {
					   dy = OFSY * 0.3;
				   }
				   else {
					   dy = 15;
				   }

				   _Grph1->DrawLine(pen_PV_Red, iX, gLy - OFSY, iX, gLy - OFSY - dy);				// 方位 

				   if (i == 0) {
					   _Grph1->DrawString(i.ToString(), fntM, brYellow, iX, gLy - OFSY);	//
				   }
				   else {
					   _Grph1->DrawString(i.ToString(), fntM, brYellow, iX - 10, gLy - OFSY);	//
				   }
			   }
			   _Grph1->DrawLine(penRed, gLx / 2, gLy - OFSY, gLx / 2, gLy - OFSY - OFSY * FactH);   // 方位180度

			 
			   ///////////////////////////////////////
			   // 航空機の描画 in PlotPlanes_Vertical
			   ///////////////////////////////////////

			   for (int i = 0; i < PlaneNum; i++) {

				   CGPCommonDefinition::DispPos2D P2d;

				   double keidoB = vec_ADS[i].Long;		//経度
				   double idoB = vec_ADS[i].Lat;		//緯度

				   double distABkm, dirABdeg;

				   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg);


				   short s = max(1, 0.2 * (50.0 - distABkm));   // 50km以内に近づくと大きく表示

				   double alt_m = vec_ADS[i].Alt_feet * 0.305;  // FEET-->meter

				   double deg = dirABdeg;
				   double BAI = max(2 / log10(gRadius_km), 1);
				   short LX_ = BAI * gLx;

				   short iX = short(LX_ * (360 * 2 + deg + gROUND_DEG - 360 + 180 / BAI) / 360) % LX_;

				   short iY;

				   if (CGPCommon::Elevation_angle_kind == 0) {
					   //高さ
					   iY = -OFSY + gLy - alt_m / 12000. * (gLy - OFSY);
				   }
				   else {
					   //角度
					   double tanA = alt_m / (1000.0*distABkm);
					   double degA = 180 / PI * atan(tanA); 

					   iY = -OFSY + gLy - degA / MaxDegRITSUMEN * (gLy - OFSY);

				   }
				   
				   int Ti_sec = vec_ADS[i].Ti_sec;

				
				   if (Ti_sec > 1) {
					   // 経過時間[秒] 経験から、電波が届かない場所近辺で、２秒以上になる。
					   _Grph1->DrawEllipse(penRed, iX - s, iY - s, 2 * s, 2 * s);
				   }
				   else {
					   _Grph1->DrawEllipse(penYellow, iX - s, iY - s, 2 * s, 2 * s);
				   }

				   P2d.X = iX - s;
				   P2d.Y = iY - s;

				   double b_a = (vec_ADS[i].HeadDirection - dirABdeg);
				   double test = cos(b_a * PI / 180.0);
				   short kindDir = 0;

				   if (test > 0.707) {
					   kindDir = 2; //遠ざかる
				   }
				   else if (test < -0.707) {
					   kindDir = -2; //近づく
				   }
				   else {
					   double test2 = sin(b_a * PI / 180.0);
					   if (test2 > 0) {
						   kindDir = 1;  // 右へ
					   }
					   else if (test2 < 0) {
						   kindDir = -1;  //左へ
					   }
				   }


				   String^ S1;
				   String^ S2;

				   if (CGPCommon::IsPlaneMark == 1) { 

					   if (!vec_ADS[i].strFligtNumber.compare(0, 3, "   ")) {
						   S1 = gcnew String(vec_ADS[i].strHex.c_str());
					   }
					   else {
						   S1 = gcnew String(vec_ADS[i].strFligtNumber.c_str());
					   }

				   }
				   else if (CGPCommon::IsPlaneMark == 2) {
					   S2 = gcnew String(alt_m.ToString("#####"));
				   }
				   else if (CGPCommon::IsPlaneMark == 3) {
					 
					   if (!vec_ADS[i].strFligtNumber.compare(0, 3, "   ")) {
						   S1 = gcnew String(vec_ADS[i].strHex.c_str());
					   }
					   else {
						   S1 = gcnew String(vec_ADS[i].strFligtNumber.c_str());
					   }

					   S2 = gcnew String(alt_m.ToString("#####"));
				   }

				   if (!std::strcmp(CGPCommon::strHex_pointing_Now.c_str(), vec_ADS[i].strHex.c_str())) { 

					   if (kindDir == 1) {

						   _Grph1->DrawString("→" + S1, fntS, brRed, iX, iY);

					   }
					   else if (kindDir == -1) {

						   _Grph1->DrawString("←" + S1, fntS, brRed, iX, iY);
					   }
					   else if (kindDir == 2) {

						   _Grph1->DrawString("＋" + S1, fntS, brRed, iX, iY);
					   }
					   else if (kindDir == -2) {

						   _Grph1->DrawString("●" + S1, fntS, brRed, iX, iY);
					   }

					   if (CGPCommon::IsPlaneMark == 2 || CGPCommon::IsPlaneMark == 3) {
						   //高度
						   _Grph1->DrawString(S2, fntS, brRed, iX + 10, iY + 10);
					   }
				   }
				   else {

					   if (kindDir == 1) {

						   _Grph1->DrawString("→" + S1, fntS, brYellow, iX, iY);

					   }
					   else if (kindDir == -1) {

						   _Grph1->DrawString("←" + S1, fntS, brYellow, iX, iY);
					   }
					   else if (kindDir == 2) {

						   _Grph1->DrawString("＋" + S1, fntS, brYellow, iX, iY);
					   }
					   else if (kindDir == -2) {

						   _Grph1->DrawString("●" + S1, fntS, brYellow, iX, iY);
					   }

					   if (CGPCommon::IsPlaneMark == 2 || CGPCommon::IsPlaneMark == 3) {
						   //高度
						   _Grph1->DrawString(S2, fntS, brYellow, iX + 10, iY + 10);
					   }
				   }

				   // 2次元場所の登録
				   CGPCommon::_mapDispPos[vec_ADS[i].strHex] = P2d; 

			   }


			   /////////////////////////////////
			   // 過去の航空機の軌跡を削除する
			   /////////////////////////////////

			   if (gCnt % 100 == 0) {  // 100/4=約25秒毎

				   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it;
				   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it2;

				   //MngFnc::WriteCsvLog("gCnt="+gCnt.ToString());

				   std::string strKeyFormer = "";
				   long int CounterFormer = -1;

				   std::set< std::string > setKeyVanish;   //重複なし

				   for (it = CGPCommon::_mltMapTrail.begin(); it != CGPCommon::_mltMapTrail.end(); it++) {

					   std::string strKey = it->first;
					   long int Counter = (it->second).Counter;

					   if (!std::strcmp(strKey.c_str(), strKeyFormer.c_str())) {
						   ; //nop
					   }
					   else {

						   if (strKeyFormer.size() > 0) {
							   if ((gCnt - CounterFormer) > 1000) {   //1000/4=250秒以上、音信が無い場合
								   setKeyVanish.insert(strKeyFormer);
							   }
						   }

					   }
					   strKeyFormer = strKey;
					   CounterFormer = Counter;

				   }

				   for (auto ite = setKeyVanish.begin(); ite != setKeyVanish.end(); ite++) {

					   std::string strKey = ite->c_str();

					   std::string strFlightNumber = CGPCommon::_mapFlightCode[strKey.c_str()];

					   String^ S1;
   
					   if (!strFlightNumber.compare(0, 3, "   ")) {
						   S1 = gcnew String(strKey.c_str());
					   }
					   else {
						   S1 = gcnew String(strFlightNumber.c_str());
					   }
					   //MngFnc::WriteCsvLog("disappear:" + S1);

					   {
						   //2024-03-06
						   //　順番 Flight,Alt,Lat,Long,Alt,Lat,Long
						   String^ Mes1 = S1 + ",";

						   int Cnt = CGPCommon::_mltMapTrail.count(strKey.c_str());

						   std::multimap<std::string, CGPCommonDefinition::strct_Trail>::iterator it;

						   it = CGPCommon::_mltMapTrail.find(strKey.c_str());

						   for (int j = 0; j < Cnt; j++) {

							   if (j == 0) {
								   double alt_m = (*it).second.Alt_m;
								   double idoB = (*it).second.Lat;
								   double keidoB = (*it).second.Long;

								   Mes1 = Mes1 + alt_m.ToString() + "," + idoB.ToString() + "," + keidoB.ToString() + ",";
							   }
							   else if (j == Cnt - 1) {
								   double alt_m = (*it).second.Alt_m;
								   double idoB = (*it).second.Lat;
								   double keidoB = (*it).second.Long;

								   Mes1 = Mes1 + alt_m.ToString() + "," + idoB.ToString() + "," + keidoB.ToString();
							   }

							   it++;
						   }

						   MngFnc::WriteCsvLog(Mes1);

					   }

					   CGPCommon::_mltMapTrail.erase(strKey.c_str());

				   }

			   }

			   ////////////////////////////
			   //　ランドマークの表示
			   ////////////////////////////

			   if (DispKind_ex % 2 == 1) {

				   //ランドマーク表示

				   for (int i = 0; i < NumLandMarks; i++) {

					   if (i == iLM) {
						   ; //nop
					   }
					   else {

						   double idoB = CGPCommon::_vec_LandMarks[i].ido;
						   double keidoB = CGPCommon::_vec_LandMarks[i].keido;
						   String^ S_kanjiName = gcnew String(CGPCommon::_vec_LandMarks[i].strLongName.c_str());

						   double distABkm, dirABdeg;

						   calc_dist_dir(idoA, keidoA, idoB, keidoB, distABkm, dirABdeg); 
						   //if ((gRadius_km * 0.5 < distABkm) && (distABkm < gRadius_km)) {
							  // ||(distABkm < 25)) { 
							  // 
							if (((gRadius_km * 0.5 < distABkm) && (distABkm < gRadius_km))||(distABkm < 25)) {

							   // gRadius_kmの内側50％のランドマークのみ表示 
							   double deg = dirABdeg;
							   double BAI = max(2 / log10(gRadius_km), 1);
							   short LX_ = BAI * gLx;

							   short iX = short(LX_ * (360 * 2 + deg + gROUND_DEG - 360 + 180 / BAI) / 360) % LX_;

							   short iY = gLy - OFSY;

							   short s = 3;
							   _Grph1->DrawRectangle(penWhite, iX - s, iY - 2 * s, 2 * s, 2 * s);

							   int len2 = S_kanjiName->Length;

							   for (int k = 0; k < len2; k++) {

								   String^ S1 = S_kanjiName->Substring(k, 1);//
								   _Grph1->DrawString(S1, fntS, brWhite, iX - 5, iY + 15 + k * 12);
							   }

						   }
					   }
				   }
			   }


			   //////////////////////
			   // 文字情報　左上側
			   //////////////////////

			   DateTime now = DateTime::Now;
			   String^ Str_Now = now.ToString("yyyy-MM-dd HH:mm:ss");
			   _Grph1->DrawString("Date:" + Str_Now, fntM, brMagenta, 5, 5);

			   _Grph1->DrawString("Center:" + S_LocName, fntM, brMagenta, 5, 20);
			   _Grph1->DrawString("Plane:" + PlaneNum.ToString(), fntM, brMagenta, 5, 40);
			  
			   int cnt = CGPCommon::_mltMapTrail.size();
			   _Grph1->DrawString("TrailSize:" + cnt.ToString(), fntM, brMagenta, 5, 55);

			   _Grph1->DrawString("gCnt:" + gCnt.ToString(), fntM, brMagenta, 5, 70);

			   _Grph1->DrawString("QueueNum:" + gNumQueue.ToString(), fntM, brMagenta, 5, 85);


			   this->pictureBox1->Refresh();  //2023-09-11

			   return(0);
		   }


	private: System::Void sub_Grph1_DrawTrail(bool bIsLanding,int penThick, short iX, short iY, short iX_former, short iY_former) {

		if (bIsLanding == true) {
			
			switch (penThick) {
			case 1:
				penDownTrail=penDownTrail1;
				break;
			case 2:
				penDownTrail = penDownTrail2;
				break;
			case 3:
				penDownTrail = penDownTrail3;
				break;
			case 4:
				penDownTrail = penDownTrail4;
				break;
			case 5:
				penDownTrail = penDownTrail5;
				break;
			case 6:
				penDownTrail = penDownTrail6;
				break;
			case 7:
				penDownTrail = penDownTrail7;
				break;
			case 8:
				penDownTrail = penDownTrail8;
				break;
			case 9:
				penDownTrail = penDownTrail9;
				break;
			case 10:
				penDownTrail = penDownTrail10;
				break;
			default:
				penDownTrail = penDownTrail1;
				;
			}

			_Grph1->DrawLine(penDownTrail, iX, iY, iX_former, iY_former);
		}
		else {
			switch (penThick) {
			case 1:
				penUpTrail = penUpTrail1;
				break;
			case 2:
				penUpTrail = penUpTrail2;
				break;
			case 3:
				penUpTrail = penUpTrail3;
				break;
			case 4:
				penUpTrail = penUpTrail4;
				break;
			case 5:
				penUpTrail = penUpTrail5;
				break;
			case 6:
				penUpTrail = penUpTrail6;
				break;
			case 7:
				penUpTrail = penUpTrail7;
				break;
			case 8:
				penUpTrail = penUpTrail8;
				break;
			case 9:
				penUpTrail = penUpTrail9;
				break;
			case 10:
				penUpTrail = penUpTrail10;
				break;
			default:
				penUpTrail = penUpTrail1;
				;
			}

			_Grph1->DrawLine(penUpTrail, iX, iY, iX_former, iY_former);
		}
		//_Grph1->DrawLine(penDownTrail, iX, iY, iX_former, iY_former);
	}

	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
 
	}
	private: System::Void tabPage0_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void fileSystemWatcher1_Changed(System::Object^ sender, System::IO::FileSystemEventArgs^ e) {

		//
		// 特定のフォルダを監視して、ファイルがコピーもしくは生成された場合にここを通ります。
		//  (デモのときもここを通ります）
		//

		this->label_KANSHI_info->Text = "ADS raw data:" + this->fileSystemWatcher1->Path + "\\" + e->Name;


		FILE* fp;

		std::string strFile, strName, strFormerName;

		MngFnc::String_to_string(e->Name, strName);

		MngFnc::String_to_string(gFormerName_for_API_BUG_taisaku, strFormerName);


		// システムのバグ？　
		// fileSystemWatcher1_Changedが2回呼ばれる現象の対策です
		if (!strFormerName.compare(strName.c_str())) {
			//2回同じファイルがくるので、後の方を使う（どうも、１回目だと上書きされてしまう瞬間があり、バグる）
			//MngFnc::WriteCsvLog("fileSystemWatcher1_Changedが2回呼ばれる:"+ gFormerName_for_API_BUG_taisaku->ToString());
			;
		}
		else {
			// 最初は、無視します。（必ず２回来ます）
			goto LAST0;
		}
		

		if (CGPCommon::IsBusyNow == false) {

			CGPCommon::IsBusyNow = true;

			std::string strADS_File_Name;
			MngFnc::String_to_string(this->fileSystemWatcher1->Path + "\\" + e->Name, strADS_File_Name);

			std::vector<strct_ADS >  vec_ADS;
			String^ Spath = gcnew String(strADS_File_Name.c_str());


			///////////////////////////////////////////// 
			// 信号１回分内の航空機（複数）の位置情報を
			// （1秒間に４回ほど、信号を取得できる）
			/////////////////////////////////////////////

			set_ADS(Spath, vec_ADS);

			///////////////////////////////////////////////
			//　マルチスレッドで描く（キューを利用）
			///////////////////////////////////////////////
			if (vec_ADS.size() > 0) {
				EnterCriticalSection(&gCS);	// 排他処理を記述
				CGPCommon::_que_vec_ADS.push(vec_ADS);
				LeaveCriticalSection(&gCS);
			}
			else {
				MngFnc::WriteCsvLog("vec_ADSのサイズが0　???　" + Spath);
			}

			CGPCommon::IsBusyNow = false;

		}
		else {
			MngFnc::WriteCsvLog("〈データ欠落）ADSファイルの更新に追いつきませんでした gCnt=" + gCnt.ToString());
		}

		if (1 == 0) {
			strFile.append("C:/tmp0/tmp_List.txt");

			errno_t err = fopen_s(&fp, strFile.c_str(), "a");

			if (fp != NULL) {

				char cbuf[256];
				strcpy_s(cbuf, strName.c_str());
				fprintf(fp, "%s\n", cbuf);

				fclose(fp);

				//? gFormerName_for_API_BUG_taisaku = e->Name;
			}

		}
LAST0:
		gFormerName_for_API_BUG_taisaku = e->Name;

	LAST1:
		;

	}
	private: System::Void fileSystemWatcher1_Created(System::Object^ sender, System::IO::FileSystemEventArgs^ e) {

		this->label_KANSHI_info->Text = "Created..." + e->Name;
	}
	private: System::Void fileSystemWatcher1_Renamed(System::Object^ sender, System::IO::RenamedEventArgs^ e) {

		this->label_KANSHI_info->Text = "Renamed..." + e->Name;

	}
	private: System::Void numericUpDown1_ValueChanged(System::Object^ sender, System::EventArgs^ e) {

		gROUND_DEG = (double)this->numericUpDown1->Value;

	}
	private: System::Void numericUpDown2_ValueChanged(System::Object^ sender, System::EventArgs^ e) {

		gDEPRS_DEG = (double)this->numericUpDown2->Value;

	}
	private: System::Void numericUpDown3_ValueChanged(System::Object^ sender, System::EventArgs^ e) {


		gRadius_km = (double)this->numericUpDown3->Value;

		if (gRadius_km <= 200) {
			this->numericUpDown3->Increment = 10;
		}
		else if (gRadius_km <= 3000) {
			this->numericUpDown3->Increment = 100;
		}
		else {
			this->numericUpDown3->Increment = 200;// 1000;
		}

	}
	private: System::Void checkBoxTrail_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {

		CGPCommon::IsTrail = this->checkBoxTrail->Checked;

	}

	private: System::Void tabControl1_Deselected(System::Object^ sender, System::Windows::Forms::TabControlEventArgs^ e) {

		CGPCommon::strLatterForSystemParamDirtyCheck.clear();

		int rowCount = this->dataGridViewSystemParamTable->RowCount;

		for (int i = 0; i < rowCount; i++) {

			String^ Str = (String^)this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value;
			std::string str;
			MngFnc::String_to_string(Str, str);
			CGPCommon::strLatterForSystemParamDirtyCheck.append(str);
		}

		if (!strcmp(CGPCommon::strFormerForSystemParamDirtyCheck.c_str(), CGPCommon::strLatterForSystemParamDirtyCheck.c_str())) {
			//同じなら、何もしない
		}
		else {
			if (MessageBox::Show("変更内容を更新しますか？", "確認", MessageBoxButtons::YesNo) ==
				System::Windows::Forms::DialogResult::Yes) {
				//更新
				this->buttonRenew_Click(sender, e);
				return;
			}
			else {

				//もとに戻す
				CGPCommon::UpdateSystemParam();

				this->dataGridViewSystemParamTable->Rows->Clear();  //全行クリアします

				int num = CGPCommon::_vecSystemParam.size();

				for (int i = 0; i < num; i++) {

					SystemParam up = CGPCommon::_vecSystemParam[i];

					this->dataGridViewSystemParamTable->Rows->Add();  //まず、一行空で追加します。

					String^ Str = gcnew String(up.NAME.c_str());  // char-->Stirng 変換の技
					this->dataGridViewSystemParamTable->Rows[i]->Cells[0]->Value = Str;
					this->dataGridViewSystemParamTable->Rows[i]->Cells[1]->Value = Convert::ToString(up.MIN_VALUE) + "～" + Convert::ToString(up.MAX_VALUE);
					this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value = Convert::ToString(up.VALUE);
				}


				// 簡易ダーティーチェック
				CGPCommon::strFormerForSystemParamDirtyCheck.clear();

				int rowCount = this->dataGridViewSystemParamTable->RowCount;

				for (int i = 0; i < rowCount; i++) {
					String^ Str = (String^)this->dataGridViewSystemParamTable->Rows[i]->Cells[2]->Value;
					std::string str;
					MngFnc::String_to_string(Str, str);
					CGPCommon::strLatterForSystemParamDirtyCheck.append(str);
				}

			}

		}

	}
	private: System::Void buttonDemoStart_Click(System::Object^ sender, System::EventArgs^ e) {
		if (this->backgroundWorker1->IsBusy) {
			return;
		}
		this->backgroundWorker1->RunWorkerAsync();

	}
	private: System::Void backgroundWorker1_DoWork(System::Object^ sender, System::ComponentModel::DoWorkEventArgs^ e) {

	L100:

		//
		// シミュレーション用の画像を使う場合
		//  ADSファイルを特定のフォルダにコピーします
		//  
		CGPCommon::_mltMapTrail.clear();

		int iStart = CGPCommon::demoStartNo;
		int iEnd = CGPCommon::demoEndNo;

		for (int i = iStart; i < iEnd; i++) {

			try {
				//  tmp_ADS_B-00000001

				char cbuf[10];
				sprintf(cbuf, "%04d", i);

				std::string strTmp1;

				strTmp1.append(DEMO_FILE).append(cbuf).append(".txt");  // "C:/ADS_GLIDE_PATH/DemoData/tmp_ADS_B-0000"

				std::string strTmp2;

				strTmp2.append(CGPCommon::_strDataFolder).append("/tmp_ADS_B-0000").append(cbuf).append(".txt");

				String^ StrTmp1 = gcnew String(strTmp1.c_str());

				String^ StrTmp2 = gcnew String(strTmp2.c_str());

				System::IO::File::Delete(StrTmp2);
				System::IO::File::Copy(StrTmp1, StrTmp2);

				int iFlag = 100.0 * (i - iStart) / (iEnd - iStart);

				this->backgroundWorker1->ReportProgress(iFlag);

			}
			catch (Exception^) {
				goto L9;  //
			}

		L9:
			Application::DoEvents();
			//::Sleep(268);   //３０分間６７００計測
			::Sleep(CGPCommon::demo_Span_ms);   //３０分間６７００計測


		}

		if (1 == 1) {
			goto L100;
		}

	}
	private: System::Void backgroundWorker1_ProgressChanged(System::Object^ sender, System::ComponentModel::ProgressChangedEventArgs^ e) {

		this->progressBar1->Value = e->ProgressPercentage;

	}
	private: System::Void backgroundWorker1_RunWorkerCompleted(System::Object^ sender, System::ComponentModel::RunWorkerCompletedEventArgs^ e) {
	}
	private: System::Void backgroundWorker2_DoWork(System::Object^ sender, System::ComponentModel::DoWorkEventArgs^ e) {

		//
		// ADSデータがキューに溜まっていたら、描画する番犬
		//

		for (;;) {

			EnterCriticalSection(&gCS);	// 排他処理を記述

			int gNumQueue = CGPCommon::_que_vec_ADS.size();

			if (gNumQueue > 0) {
				CGPCommon::_vec_ADS = CGPCommon::_que_vec_ADS.front();	//先頭から取る
				CGPCommon::_que_vec_ADS.pop();				//先頭を削除
			}
			LeaveCriticalSection(&gCS);

			int s1 = CGPCommon::_vec_ADS.size();

			//MngFnc::WriteCsvLog("gNumQueue=" + gNumQueue.ToString() + "  CGPCommon::_vec_ADS.size=" + s1.ToString());

			if (gNumQueue > 0) {

				int iFlag = PROGRESS_DRAW;
				this->backgroundWorker2->ReportProgress(iFlag);

			}

			Application::DoEvents();
			Sleep(20);
			//Sleep(10);

		}


	}
	private: System::Void backgroundWorker2_ProgressChanged(System::Object^ sender, System::ComponentModel::ProgressChangedEventArgs^ e) {


		//DateTime start = DateTime::Now;
		//・・・(時間のかかる処理　必要ならＮ回繰り返す）
		//	DateTime end = DateTime::Now;
		//TimeSpan t = end.Subtract(start);
		//MessageBox::Show((t.Seconds * 1000 + t.Milliseconds).ToString("########"));


		if (e->ProgressPercentage == PROGRESS_DRAW) {

			DateTime start = DateTime::Now;

			if (gDEPRS_DEG == 90) {
				//立面
				PlotPlanes_Vertical(CGPCommon::_vec_ADS);
			}
			else {
				//3D、平面図
				PlotPlanes_3D_or_Horiz(CGPCommon::_vec_ADS, gDEPRS_DEG, gRadius_km);
			}

			DateTime end = DateTime::Now;
			TimeSpan t = end.Subtract(start);

			if ((t.Seconds * 1000 + t.Milliseconds) > 1) {
				//MngFnc::WriteCsvLog("DrawTime: " + (t.Seconds * 1000 + t.Milliseconds).ToString("########"));
			}

			gCnt = gCnt + 1;

		}

	}
	private: System::Void backgroundWorker2_RunWorkerCompleted(System::Object^ sender, System::ComponentModel::RunWorkerCompletedEventArgs^ e) {
	}
	private: System::Void Form1_Shown(System::Object^ sender, System::EventArgs^ e) {

		if (this->backgroundWorker2->IsBusy) {
			return;
		}
		this->backgroundWorker2->RunWorkerAsync();
	}
	private: System::Void progressBar1_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void pictureBox1_Resize(System::Object^ sender, System::EventArgs^ e) {

		//Form1_Resizeから呼ばれる

		int w = pictureBox1->Width;
		int h = pictureBox1->Height;

		if (w * h == 0) {
			w = 3000;
			h = 2000;
		}

		gLx = w;
		gLy = h;
		
		{
			// pictureBox2は、隠れており、pictureBox1に追随します。
			g_bmpPicBox2 = gcnew Bitmap(gLx, gLy);
			pictureBox2->Image = g_bmpPicBox2;						// in pictureBox1_Resize
			_Grph2 = Graphics::FromImage(pictureBox2->Image);		// in pictureBox1_Resize
		}

		bIsGenerateMap = true;
	
		return;
	}
	private: System::Void Form1_Resize(System::Object^ sender, System::EventArgs^ e) {
		pictureBox1_Resize(sender, e);
	}
private: System::Void listBoxKijyunLoc_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	bIsGenerateMap = true;
}
};
}
