// Mat2.cpp: Mat2 �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"  
#include "Mat2.h"
#include "math.h"

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

Mat2::Mat2()
{
	 m_11=0.0;
	 m_12=0.0;
 	 m_21=0.0;
	 m_22=0.0;
}

Mat2::~Mat2()
{

}

Mat2::Mat2(double f[4])
{
	 m_11=f[0];
	 m_12=f[1];
 	 m_21=f[2];
	 m_22=f[3];
}

 
Mat2::Mat2(double a11,double a12,	//<---�s���1�s�ځi���j
		       double a21,double a22)	//<---�s���2�s�ځi���j
{
	 m_11=a11;
	 m_12=a12; 
	 m_21=a21;
	 m_22=a22;

}



Mat2 Mat2::operator +(Mat2 ob2)
{
  Mat2 tmp;

  tmp.m_11=m_11+ob2.m_11;
  tmp.m_12=m_12+ob2.m_12;
 
  tmp.m_21=m_21+ob2.m_21;
  tmp.m_22=m_22+ob2.m_22;

  return(tmp);

}

Mat2 Mat2::operator -(Mat2 ob2)
{
  Mat2 tmp;

  tmp.m_11=m_11-ob2.m_11;
  tmp.m_12=m_12-ob2.m_12;
 
  tmp.m_21=m_21-ob2.m_21;
  tmp.m_22=m_22-ob2.m_22;

  return(tmp);

}


Mat2 Mat2::operator +()
{
 
	return *this;

}

Mat2 Mat2::operator -()
{

	 Mat2 tmp;

	 tmp.m_11=-m_11;
	 tmp.m_12=-m_12;
 
	 tmp.m_21=-m_21;
	 tmp.m_22=-m_22;
 
	 return(tmp);

}


Vct2 Mat2::operator*(Vct2 v)	// �s��Əc�x�N�g���̐� Mv
{
  Vct2 tmp;

  tmp.x=m_11*v.x +m_12*v.y;
  tmp.y=m_21*v.x +m_22*v.y;  
 
  return(tmp);

}

Mat2 Mat2::Transposed()	// �]�u�s��
{
  Mat2 tmp;

  tmp.m_11=m_11;
  tmp.m_12=m_21; 
  
  tmp.m_21=m_12;  
  tmp.m_22=m_22;  
  
  return(tmp);
}
 

Mat2 Mat2::operator *(Mat2 ob2)
{
  Mat2 tmp;
 
  tmp.m_11=m_11*ob2.m_11+m_12*ob2.m_21;
  tmp.m_12=m_11*ob2.m_12+m_12*ob2.m_22; 
  tmp.m_21=m_21*ob2.m_11+m_22*ob2.m_21;  
  tmp.m_22=m_21*ob2.m_12+m_22*ob2.m_22;  
  
  return(tmp);

}

//�ȉ��A�t�����h�֐�
Mat2 operator *(double s,Mat2 ob2)
{
	Mat2 tmp;
 
	tmp.m_11=s*ob2.m_11;
	tmp.m_12=s*ob2.m_12;
 
	tmp.m_21=s*ob2.m_21;
	tmp.m_22=s*ob2.m_22;
  
	return(tmp);

}

double Mat2::Trace()  //�g���[�X�i�Ίp�����̘a�j
{
	double f=m_11+m_22;
	return(f);
}


double Mat2::det()  //�s��
{
	double f=+m_11*m_22-m_12*m_21;  //ad-bc
 
	return(f);
}
 
Mat2 Mat2::Inverse()	// �t�s��
{
  Mat2 tmp;
	
  double determinant= this->det() ;
  if ( fabs(determinant) <Vct2Const::ZERO_TOLERANCE ){		//�s�񎮂��O
	  return tmp;	//�ԃo�b�e���G���[�ł��悢 
  }  
 
  tmp.m_11= m_22/determinant;
  tmp.m_12=-m_12/determinant;  
  tmp.m_21=-m_21/determinant; 
  tmp.m_22= m_11/determinant; 
 
  return(tmp);
}


bool Mat2::set_with_2column_vector
	(double tate1[2],double tate2[2]) 	// 2�̗�x�N�g���ɂ��ݒ�
{
	this->m_11=tate1[0];
	this->m_21=tate1[1];
 
	this->m_12=tate2[0];
	this->m_22=tate2[1];
 
	return (0);
}

bool Mat2::set_axis_rot(const double deg)
{
	double radi=deg*Vct2Const::PI_180; //���W�A���ɂ���

	//��1��
	this->m_11=cos(radi);
	this->m_21=sin(radi); 

	//��2��
	this->m_12=-sin(radi);
	this->m_22=cos(radi); 
  
	return (0);

}
 

bool Mat2::is_SO2_matrix()
{

	double determinant=this->det();
	if ( fabs(determinant-1.0)>Vct2Const::ABOUT_ZERO){
		return false;
	}

	//��]�s��̔��f  �]�u�s��Ƃ̐ς��A�P�ʍs��ɂȂ邩�H
	Mat2 A,B,C;
	A=*this;
	B=A.Transposed();
	C=A*B;
	if (fabs(C.m_11-1.0)>Vct2Const::ABOUT_ZERO)return(false);
	if (fabs(C.m_22-1.0)>Vct2Const::ABOUT_ZERO)return(false);
 
	if (fabs(C.m_12)>Vct2Const::ABOUT_ZERO)return(false);
	if (fabs(C.m_21)>Vct2Const::ABOUT_ZERO)return(false);	

	return true;
}

 

bool Mat2::set_with_2column_vector(
		const Vct2 f1,
		const Vct2 f2 ) 	// 2�̗�x�N�g���ɂ��ݒ�
{
	this->m_11=f1.x;
	this->m_21=f1.y;
 
	this->m_12=f2.x;
	this->m_22=f2.y;
  
	return (0);
}