// Vct2.cpp: Vct2 �N���X�̃C���v�������e�[�V����
//
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"  
#include "Vct2.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

Vct2::Vct2()
{
	x=0.0;
	y=0.0;
 
}

Vct2::~Vct2()
{

}

double Vct2::absolute() const
{
	return(sqrt(x*x+y*y));
}
double Vct2::length() const
{
	return(this->absolute());
}

bool Vct2::get_norm_vector(Vct2& w) const
{
 
 	double r=sqrt(x*x+y*y);
	  
	if ( fabs(r) <= Vct2Const::ZERO_TOLERANCE ) {
		return(false);
	}
 
	w.x=x/r;
	w.y=y/r;

	return(true);
}

double Vct2::operator|(Vct2 ob2) const      // �x�N�g���ǂ����̓���
{
  	double r=x*ob2.x+y*ob2.y;
  	return(r);
}

double Vct2::inner_product(const Vct2 v, const Vct2 w)
{
 
  	double r=v.x*w.x+v.y*w.y;
  	return(r);
 
}

Vct2::Vct2(double a, double b)
{
	x=a;
	y=b;
}

Vct2 Vct2::operator/(double s) const
{

	if (fabs(s) <Vct2Const::ZERO_TOLERANCE ) {return *this;}

    Vct2 tmp;
    tmp.x=x/s;
    tmp.y=y/s;

    return(tmp);
}

Vct2 Vct2::operator +(Vct2 ob2) const
{
  Vct2 tmp;
  tmp.x=x+ob2.x;
  tmp.y=y+ob2.y;
 
  return(tmp);
}
   
Vct2 Vct2::operator -(Vct2 ob2) const
{
  Vct2 tmp;
  tmp.x=x-ob2.x;
  tmp.y=y-ob2.y;
 
  return(tmp);

}

Vct2 Vct2::operator +() const
{
	return *this;
}

Vct2 Vct2::operator -() const
{
	Vct2 tmp;
	tmp.x=-x;
	tmp.y=-y;
 
	return(tmp);

}

bool Vct2::set(const double buf[2])
{

	x=buf[0];
	y=buf[1];

	return(true);

} 

bool Vct2::set(const double a,const double b)
{

	x=a;
	y=b;

	return(true);

} 
 
bool Vct2::get(double buf[2])	//�擾
{
	buf[0]=this->x;
	buf[1]=this->y;
 
	return(true);
}

bool Vct2::get(double& a,double& b)  //�擾
{
	a=this->x;
	b=this->y;
 
	return(true);
}

double Vct2::outer_product_z_component_with(const Vct2 w) const
{ 
	//�O�ς�Z����
	 
	double r=(this->x)*w.y - (this->y)*w.x;
	
	return(r);
}
 
bool Vct2::is_parallel_to(const Vct2 w) const  // ���s���H
{ 
	// ���s�̒�`
	// �O�σx�N�g���̑傫�����A�O�Ȃ�Ε��s�Ƃ���B
	double len=(*this).outer_product_z_component_with(w);

	//double len=((*this)^w).length();
	if ( fabs(len) < Vct2Const::ABOUT_ZERO  ) {
		return(true);
	}
	else{
		return(false);
	}
}
 
bool Vct2::is_orthogonal_to(const Vct2 w) const // �������H
{
	// ���� 
	double naiseki=(*this)|w;
	if ( fabs(naiseki) < Vct2Const::ABOUT_ZERO ) {
		return(true);
	}
	else{
		return(false);
	}
}
	//�ȉ��A�t�����h�֐�
 

Vct2 operator *(double s,Vct2 v)
{
  Vct2 tmp;
  tmp.x=s*v.x;
  tmp.y=s*v.y;
  
  return(tmp);

}
 

 

